function storeUservisitHistory(whomid,pagename){

			//alert(whomid+"--"+pagename);
			$.post("resources/ajax/record-user-visit.php",{varwhomid:whomid,varpagename:pagename},function (data){		
				
				 
			
		})

}

function storeUservisitHistory2(whomid,pagename,objid){
	//alert(whomid+"--"+pagename);
			$.post("resources/ajax/record-user-visit.php",{varwhomid:whomid,varpagename:pagename,varobjid:objid},function (data){		
				
				 
			
		})

	
}
function updateUservisitHistoryendtime(){
            alert("hi");
			var parameter='param';
			$.post("resources/ajax/record-user-visit.php",{varwhomidendtime:parameter},function (data){		
				//alert(data);
				 
			
		})

}


function isNumber(evt) {
        var iKeyCode = (evt.which) ? evt.which : evt.keyCode
        if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
            return false;

        return true;
    }

		function loginFun(){
		var email=$("#email").val();	
		var password=$("#password").val();
		if(email==''){
		alert("Enter your email id.");	
		document.getElementById("email").focus();
		return false;
		}
		if(password==''){
		alert("Enter your password. ");	
		document.getElementById("password").focus();
		return false;
		}
		
		$(".logindiv").html(' <button class="btn btn-mini  loginBtn" type="button"  style="padding-top:0;"><img src="assets/img/giphy.gif" style="height:50px;" /></button>');
			
			//alert(email);
			$.post("resources/ajax/register-ajax.php",{varloginemail:email,varloginpassword:password},function (data){
				//alert(data);
				
				if(data==2){
					$("#message").html("Wrong Credentials.");
						$(".logindiv").html('<button class="btn btn-mini  loginBtn" type="button"  onClick="loginFun()">LOGIN</button>');
				}else{
					
					window.location.href=data;
				
				}
				
				
			});
		}	

$(document).ready(function(){
	
    $(".paymentcard").click(function(){
      var id = $(this).attr('id');  
	   
	  $("#typehidden").val(id);
	  var confirmuser=confirm("Payment will be made so you want to proceed?");
	  
	 
	  if(confirmuser){
		   document.getElementById("checkout").style.pointerEvents = "none"; //form area non clickable
	       $('body').css('opacity', 0.2); //add opacity to body tab
		   $.post("payment-action.php",$('form#checkout').serialize(),function (data2){		
				
			//alert(data2);	
        window.location=data2;			
			
		}) 
	  } 
	

  });
	
	
	

// Get value from editor of profile page

var activity=$("#activity").val();
if(activity==''){
$("#activity").html("Text Here.");	

}

//validation for login page
$("#login").validate({
        rules: {
            
            email: {
                required: true,
                email: true
            },
            
            password: {
                required: true
                
            }
            
        },
        messages: {
            
            email: "Registered email address required",
            password: {
                required: "Password is required"
                 
            }
             
        },
		
		 errorPlacement: function(error, element) {
            if (element.type == 'input') {
                error.appendTo(element.parent().parent());
            }
            else {
              error.appendTo(element.parent().parent());
            }
        }
		
    });	

 


   $(".loginBtn").click(function(){
			if($("#login").valid()){
				 loginFun();
				}else{
					 //
				}
					  
   })  


   //validation for create event page
$("#eventsform").validate({
		 
        rules: {
            location: "required",
			event_type:"required",
            email: {
                required: true,
                email: true
            },
            phone: {
                required: true
                
            },
			singledate: {
                required: true,
                date: true
            },
			daterange:{
				required: true,
                date: true
			},
			bookday:{
			   required: true
			},
			event_type2:{
				required: true
			}
             
        },
        messages: {
            location: "Event location is required",
			event_type: "Event type is required",
            email: "Valid email address is required",
            phone: {
                required: "Phone number is required"
                 
            },
			singledate: {
                required: "Event date is required"                
            },
			daterange: {
                required: "Event date is required"                
            },
			bookday:"Day is required",
			event_type2:"Select one option"
			 
             
        },
		 errorPlacement: function(error, element) {
		if (element.type == 'input') {
			error.appendTo(element.parent().parent());
		}
		else {
		  error.appendTo(element.parent().parent());
		}
	}
		
		
		
    });
	
	
	   
	 $(".createevent").click(function(){  
		  
				if($("#eventsform").valid()){
					createEvents2();
				}else{
					//alert("noo");
				}
					  
		  
		 })
	
	








   
	
	
	
});



 