<?php
echo "No smart work.";
?>