<?php 
$title="Login";

?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		


<style>

.navbar-inner{
min-height:43px;
// background-image: url("images/header-login.png");
background-color: #4267b2;
background-size:60px 60px!important;
background-position: center; 
}
.navbar{
min-height:43px;	
}
.navbar-inner .bit{
    position: absolute;
    height: 94px;
    width: 94px;
    left: 48%;
    top: 0px;
    margin-left: -47px;
	z-index:9999;
	padding:26px;
	font-size:28px;
	color:#ffffff;
	font-weight:600;
    letter-spacing: 5px;
}
footer{
margin: 0;	
}
#content{
min-height: 100px !important;	
}

</style>
</head>

<body>
		<!-- start: Header -->
  <?php//include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	<div class="navbar loginnav">
		<div class="navbar-inner">
			<div class="container">
				 
						<div class="bit bit--logo text--center" data-reactid="6"><div class="bit__content" data-reactid="7"><img src="images/logo2.png" style="height:100px;" /> </div></div>		
		
				
			</div>
		</div>
	</div>
	
	
	
	
	
	
	
	
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
			  <?php  //include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->


			<!-- start: Content -->
			<div id="content" class="col-lg-12 login-content">
			
			<form name="login" id="login" method="post">
			 
		 
			<div class="row" >		
				<div class="col-lg-12">
					<div class="box">
					
					
					
					   
					 	<div class="row">		
								<div class="form-group" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								 <div class="controls">
								   <div  class="login-heading">   Sign In &nbsp; &nbsp; <span  id="message" style="color: red;font-weight: 600;"></span></div>
								</div>								   
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
		
					 
					 	<div class="row">		
								<div class="form-group" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									 
										<div class="input-group date col-sm-12">
										 <input class="form-control focused input-border-right-white" id="email" name="email"   type="text" placeholder="Email" required >
									     <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
										  </div>
									 
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
							
							
							 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									 
										<div class="input-group date col-sm-12">
										 <input class="form-control focused input-border-right-white" id="password" name="password"   type="password" placeholder="Password" required>
									    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
										 </div>
									 
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
						 
								 
					 
								
								 
								<div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls logindiv">
								 
										
										   <button class="btn btn-mini  loginBtn" type="button"   >LOGIN</button>
										   
										   
									 
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								
								<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls  ">
								 
										
										  Don't have an account? <a href="registration.php">Sign up</a>
										   
										 
									 
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								 
 
										 
									</div>
								</div><!--/col-->
							
							</div><!--/row-->

							</form>
			
			
			
			    <div class="row ">	</div>
								 
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
		<footer class="loginBottomsec">
		
		<div class="row">
			
			<div class="col-sm-5">
				 
			</div><!--/.col-->
			
			<div class="col-sm-7 text-right">
				 
			</div><!--/.col-->	
			
		</div><!--/.row-->
		
	</footer>
		<footer>
		
		<div class="row">
			
			<div class="col-sm-5">
				&copy; 2017 Creative Xchange.
			</div><!--/.col-->
			
			<div class="col-sm-7 text-right">
				 <a href="">Privacy Policy | Terms and Conditions</a>
			</div><!--/.col-->	
			
		</div><!--/.row-->
		
	</footer>
	
	
	
<?php  //include("resources/templates/footer.php"); ?>	
	
<?php  //include("resources/templates/script.php"); ?>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.validate.js"></script>
<script src="assets/js/myjs.js"></script>
<script>

$.validator.setDefaults({
    submitHandler: function() {
        //write ur code
    }
	
});
		

$(document).ready(function() {

	
})	

</script>


</body>
</html>
