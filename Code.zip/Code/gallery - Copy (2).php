 <?php
include("resources/includes/functions.php");
checkLogin();
$title='My Gallery';
$id=$_SESSION["user"];

$user_type=$_SESSION["utype"];
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
$name=$result['name'];


/*code for ratings*/			 
if(!isset($_SESSION['user_id'])){
  $_SESSION['user_id'] = $id;
}
			 
require_once __DIR__ . "/config.php";

	/*code for ratings end*/
?> 
 <!DOCTYPE html>
<html lang="en">
<head>
	
<?php  include("resources/templates/head.php"); ?>	
	 
	
	<style>
.default{
 
height: 28px !important;
border-radius:3px;
}
</style>	
		
	<style>
.col-sm-3{
padding-left:0px;
padding-right:2px;
}
.row{
margin-left:0px;
margin-right:0px;
}
/* The Modal (background) */
.modal {
display: none; /* Hidden by default */
position: fixed; /* Stay in place */
z-index: 1; /* Sit on top */
padding-top: 47px; /* Location of the box */
left: 0;
top: 0;
width: 100%; /* Full width */
height: 100%; /* Full height */
overflow: auto; /* Enable scroll if needed */
background-color: rgb(0,0,0); /* Fallback color */
background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
background-color: #fefefe;
margin: auto;
padding: 20px;
border: 1px solid #888;
width: 50%;
}

/* The Close Button */
.close2 {
color: #aaaaaa;
float: right;
font-size: 28px;
font-weight: bold;
}

.close2:hover,
.close2:focus {
color: #000;
text-decoration: none;
cursor: pointer;
}

.booknow:hover{
background-color:#fff;
padding:4px 8px;
border-radius:2px;
}
#profiledtl{
height: 350px;
margin-bottom: 24px;
margin-left: 5px;
max-width: 99.1%;
}



//below code for slider 
ul{
			list-style: none outside none;
		    padding-left: 0;
            margin: 0;
		}
        .demo .item{
            margin-bottom: 5px;
        }
		 
		.content-slider h3 {
		    margin: 0;
		    padding: 70px 0;
		}
		.demo{
			width: 100%;
		}
		
		
		.title{		     
    
    font-family: bo;
    font-size: 22px;
	margin-left:2%;
	margin-bottom:2px;
	cursor:pointer;
   }
		
	 
  .img-thumbnail:hover {
    
     -ms-transform: scale(1.5);
    -moz-transform: scale(1.2);
    -webkit-transform: scale(1.2);
    -o-transform: scale(1.2);
    transform: scale(1.5);
	border-radius:2px;
	z-index:99;
	position:relative;
}	
		
	.profileBtnDiv ul li {
float:right;
margin-right:20px;
list-style-type:none;
margin-top: 5px;
font-weight:600;
border-right:1px solid #d3d6db;
padding-right: 9px;

}	
.profileBtnDiv ul li a{
text-decoration:none;
}	

	</style>
			
 
		 	
</head>

<body>
<div class="se-pre-con"></div>
		<!-- start: Header -->
<?php  include("resources/templates/header.php"); ?>	
	<!-- start: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
<?php  include("resources/templates/left-menu.php"); ?>	
			
			<!-- end: Main Menu -->
 


<form name="musicians" id="musiciansform" method="post" action="musician-gallery.php">
                         <input type="hidden" name="q" id="q2" value="" />

                       </form>	
					   
<form name="photographerform" id="photographerform" method="post" action="show-photographer-gallery.php">
                         <input type="hidden" name="q" id="q" value="" />

                       </form>	
 		
		
		
			<!-- start: Content -->
			<div id="content" class="col-sm-12" style="z-index:0;">
				 
			
							<div class="row sortable">
				       <div class="col-lg-12" style="z-index:0;">
					     <div class="box">
						   <div class="col-md-3 col-sm-6 col-xs-12" > 
						      <div class=" col-lg-12 expplorediv">
							   <div class="expplore-pic"><img src="images/profile/whatshappening.jpg" class="expplore-artist"/> </div> 
							   <div class="expplorecate" ><a href="">What's Happening</a> </div>
						   </div>
						   </div>
					   
						  <div class="col-md-3 col-sm-6 col-xs-12" > 
						      <div class=" col-lg-12 expplorediv">
							   <div class="expplore-pic"><img src="images/profile/pgrapher.jpg" class="expplore-artist"/> </div> 
							   <div class="expplorecate" ><a href="photographers-gallery.php">Photographers </a></div>
						   </div>
						   </div>
						   
						  <div class="col-md-3 col-sm-6 col-xs-12" > 
						      <div class=" col-lg-12 expplorediv">
							   <div class="expplore-pic"><img src="images/profile/musician-home.jpg" class="expplore-artist"/> </div> 
							   <div class="expplorecate" ><a href="musician-gallery.php">Musicians</a> </div>
						   </div>
						   </div>
						 
							 
			   
			           </div>
					  </div>
				 </div>
			
			
			
		
			<div class="row sortable">
				<div class="col-lg-12">
					<div class="box">
						
						 <div class="row home-category-txt">
						 <div style="margin-bottom:20px;" class="col-lg-11"> <h1>Photographers</h1></div>
						  <div style="margin-bottom:20px; padding-top:20px;" class="col-lg-1"><a href="photographers-gallery.php">See All >> </a></div>
						 </div>
					  
									<div class="row">
									 <div class="col-lg-12">
									<?php
									  $query="select id,name,profile,address,city,state,country from user_register where  user_type='1' and professionid='1' and status='1'";
											   $sql = $dbh->prepare($query);
											   $sql->execute();
											   //echo $sql->rowCount();
											   if($sql->rowCount()>0){ 
											   
												   
									?>
									
									<div class="demo">
										 
										<div class="item">
											<ul id="content-slider" class="content-slider" >
											   
											   <?php
											   
											   while($rec_pic = $sql->fetch(PDO::FETCH_ASSOC))
											   {
															 $uid=$rec_pic['id'];
																   if($rec_pic['profile']!=''){
																		$img=$rec_pic['profile'];
																		}
																		else{$img='galleryProfilePic.png';}
																		$star->id = $uid;
																		 
																		// Get city and state name
																		$city=$rec_pic['city'];
														  $query_city="select city from cities where id='$city'";
														 $res_city = $dbh->prepare($query_city);
														 $res_city->execute();	
														 $rec_city= $res_city->fetch(PDO::FETCH_ASSOC); 
														 
														 if(isset($rec_pic['state']) && $rec_pic['state']!=''){
															 $state=$rec_pic['state'];
															 $query_state="select state from states where state_code='$state'";
														 $res_state = $dbh->prepare($query_state);
														 $res_state->execute();	
														 $rec_state= $res_state->fetch(PDO::FETCH_ASSOC); 
														 }    
																 
																 
											   ?>

											   <li>
													<img class="img-thumbnail" src="images/profile/<?php echo $img;?>"  style="height:190px;width: 253px;"
													  data-image="images/profile/<?php echo $img;?>" data-gallery='gallery' data-desc='<?php echo ucwords($rec_pic['name']);?>'  onclick="redirectUser(<?php echo $uid;?>)">
													  <div class="row">
																	 <div class="col-lg-12"> <span class="gallery-name"><?php echo ucwords($rec_pic['name']);?> <span></div>	
																	  <div class="col-lg-12"> <span class="gallery-address">
																		<?php //if(isset($rec_pic['address']) && $rec_pic['address']!=''){echo $rec_pic['address'].",";}?>  <?php if(isset($rec_pic['city']) && $rec_pic['city']!=''){echo $rec_city['city'].",";}?><?php if(isset($rec_pic['state']) && $rec_pic['state']!=''){echo $rec_state['state'].",";}?><?php if(isset($rec_pic['country'])){echo $result['country'];}?></span>
																	  </div> 
																	  <div class="col-lg-12"> <?php echo     $star->getRating("userChoose size-3"); ?></div>								  
																</div>	
														
												</li>
											   
											   <?php
											   }
											   ?>
											   
											   
												 
												
												  
											</ul>
										</div>						

									</div>	
									 <?php
									} else{
										?>
										
										<div style="margin-left: 2%;margin-top: 10px;margin-bottom: 10px;"> No Content</div>
										<?php  		
										
										}
								   ?>
									
								</div>	

 							</div>		
	 
															
															
						 	
					</div><!--/col-->
				</div><!--/col-->
			
			</div><!--/row-->

    
		<div class="row sortable">
				<div class="col-lg-12">
					<div class="box">
						
						 <div class="row home-category-txt">
						 <div style="margin-bottom:20px;" class="col-lg-11"> <h1>Musicians</h1></div>
						  <div style="margin-bottom:20px; padding-top:20px;" class="col-lg-1"><a href="musician-gallery.php">See All >> </a></div>
						 </div>
					  
									<div class="row">
									 <div class="col-lg-12">
									<?php
									  $query="select id,name,profile,address,city,state,country from user_register where  user_type='1' and professionid='2' and status='1'";
											   $sql = $dbh->prepare($query);
											   $sql->execute();
											   //echo $sql->rowCount();
											   if($sql->rowCount()>0){ 
											   
												   
									?>
									
									<div class="demo">
										 
										<div class="item">
											<ul id="content-slider" class="content-slider" >
											   
											   <?php
											   
											   while($rec_pic = $sql->fetch(PDO::FETCH_ASSOC))
											   {
															 $uid=$rec_pic['id'];
																   if($rec_pic['profile']!=''){
																		$img=$rec_pic['profile'];
																		}
																		else{$img='galleryProfilePic.png';}
																		$star->id = $uid;
																		 
																		// Get city and state name
																		$city=$rec_pic['city'];
														  $query_city="select city from cities where id='$city'";
														 $res_city = $dbh->prepare($query_city);
														 $res_city->execute();	
														 $rec_city= $res_city->fetch(PDO::FETCH_ASSOC); 
														 
														 if(isset($rec_pic['state']) && $rec_pic['state']!=''){
															 $state=$rec_pic['state'];
															 $query_state="select state from states where state_code='$state'";
														 $res_state = $dbh->prepare($query_state);
														 $res_state->execute();	
														 $rec_state= $res_state->fetch(PDO::FETCH_ASSOC); 
														 }    
																 
																 
											   ?>

											   <li>
													<img class="img-thumbnail" src="images/profile/<?php echo $img;?>"  style="height:190px;width: 253px;"
													  data-image="images/profile/<?php echo $img;?>" data-gallery='gallery' data-desc='<?php echo ucwords($rec_pic['name']);?>'  onclick="redirectUser2(<?php echo $uid;?>)">
													  <div class="row">
																	 <div class="col-lg-12"> <span class="gallery-name"><?php echo ucwords($rec_pic['name']);?> <span></div>	
																	  <div class="col-lg-12"> <span class="gallery-address">
																		<?php //if(isset($rec_pic['address']) && $rec_pic['address']!=''){echo $rec_pic['address'].",";}?>  <?php if(isset($rec_pic['city']) && $rec_pic['city']!=''){echo $rec_city['city'].",";}?><?php if(isset($rec_pic['state']) && $rec_pic['state']!=''){echo $rec_state['state'].",";}?><?php if(isset($rec_pic['country'])){echo $result['country'];}?></span>
																	  </div> 
																	  <div class="col-lg-12"> <?php echo     $star->getRating("userChoose size-3"); ?></div>								  
																</div>	
														
												</li>
											   
											   <?php
											   }
											   ?>
											   
											   
												 
												
												  
											</ul>
										</div>						

									</div>	
									 <?php
									} else{
										?>
										
										<div style="margin-left: 2%;margin-top: 10px;margin-bottom: 10px;"> No Content</div>
										<?php  		
										
										}
								   ?>
									
								</div>	

 							</div>		
	 
															
															
						 	
					</div><!--/col-->
				</div><!--/col-->
			
			</div><!--/row-->
	
	
	
	
	
	
					
			</div>
			<!-- end: Content -->
			
 

 			
				</div><!--/row-->
		
		 


    
  
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 <?php  include("resources/templates/footer.php"); ?>		
	


 
	<?php  include("resources/templates/script.php"); ?>	
	<script src="assets/js/photographer-gallery.js"></script>
	 
	  
	 
 <script>
  

	//paste this code under head tag or in a seperate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
 
	
 
	
function redirectUser(v){
	$("#q").val(v);
	$("#photographerform").submit();
}

function redirectUser2(v){
	$("#q2").val(v);
	$("#musiciansform").submit();
}
</script>

 

</body>

</html>