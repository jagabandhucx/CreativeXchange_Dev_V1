<?php 
include("resources/includes/functions.php");
checkLogin();
$title="Your Notifications ";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
 
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
			 

$query_state="select * from states";
$sql_state = $dbh->prepare($query_state);
             $sql_state->execute();
             	 


$query_cities="select * from cities";
$sql_cities = $dbh->prepare($query_cities);
             $sql_cities->execute();

	
$query_profession="select * from professions where id='$result[professionid]'";
$sql_profession = $dbh->prepare($query_profession);
 $sql_profession->execute();	
$rec_profession_name= $sql_profession->fetch(PDO::FETCH_ASSOC); 
	//echo $rec_profession_name['name'];	 

$name=$result['name'];	





?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		
<style>
#message{
text-align: center;
font-size: 18px;
background-color: #ebf8a4;
color: #000;
border-radius: 2px;
border:1px solid #a2d246;
}
.form-control{
	border-right: #fff;	
}




</style>


</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
			  <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->


			<!-- start: Content -->
			<div id="content" class="col-sm-12">
			
			<form name="passwordform" id="passwordform" method="post">
			 
		 
			<div class="row" >		
				<div class="col-lg-12">
				<div class="row" >		
				<div class="col-sm-2"></div>
					<div class="col-sm-7" ><span style="font-size:16px;">&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-bullhorn"></i> Your Notifications</span></div>
			   <div class="col-sm-3"></div>
			   </div>
				<div class="row" >

				<div class="col-sm-2"></div>
				<div class="col-sm-7">
					<div class="box">
					<ul class="tickets notification-dtls">
					<?php
					   $sql_notification2="select * from notifications where noti_to='$id' order by id desc limit 0,5";
					   $res_notification2 = $dbh->prepare($sql_notification2);
					   $res_notification2->execute();
					   while($rec_noti = $res_notification2->fetch(PDO::FETCH_ASSOC))
							   {
								   
								   $tbl_name=$rec_noti['tbl_name'];
								   $tbl_id=$rec_noti['tbl_id'];
								   $noti_from=$rec_noti['noti_from'];
								   $noti_to =$rec_noti['noti_to'];
								   $date_noti=$rec_noti['date'];
								   
								   
									   $getname="select name,profile from user_register where id='$noti_from'";  
									   $res_getname = $dbh->prepare($getname);
                                       $res_getname->execute();
									   $rec_getname = $res_getname->fetch(PDO::FETCH_ASSOC);
									   $noti_from_name=$rec_getname['name'];					   
								  
										$eventid=$tbl_id;
									   $elapsed_notification_time=time_elapsed_string($date_noti);
									   if($tbl_name=='events'){
										    $redirect_page="show-event-details.php?qs=".base64_encode($eventid);
									   }
					
					?>
						 
							
							<!--- <li class="notificationsli" id="<?php echo $rec_noti['id']; ?>">
							 
										<?php if(isset($rec_getname['profile']) && $rec_getname['profile']!=''){ ?>
										
										<span class="avatar"><img src="images/profile-thumbnail/<?php echo $rec_getname['profile'];?>"  class="profile-pic"/></span>
										
										<?php } else {  ?>
                                      <span class="avatar"> <img src="images/profile-thumbnail/user.png" class="dker profile-pic"></span>
										<?php } ?>
							 
                                    <a href="<?php echo $redirect_page;?>">
										<span class="header" >
											<span class="from">
										    	<?php echo ucwords(wordwrap($noti_from_name,16));?> 
										     </span>
											 <span class="message">
                                            <?php echo substr($rec_noti['noti_msg'],0,25);?>
                                        </span> 
											  	
										
										</span>
                                       <span class="time">
										    	<?php echo $elapsed_notification_time;?>
									   </span>

                                    </a>
									      	 										
                                </li>-->
								
								 <li class="notificationsli" id="<?php echo $rec_noti['id']; ?>">
							 
										
							 
                                    <a href="<?php echo $redirect_page;?>">
										
                                      

                                    </a>
									
									 <div class="row">
									 <div  class="col-sm-1">
									 <?php if(isset($rec_getname['profile']) && $rec_getname['profile']!=''){ ?>
										
										<span class="avatar"><img src="images/profile-thumbnail/<?php echo $rec_getname['profile'];?>"  class="profile-pic2"/></span>
										
										<?php } else {  ?>
                                      <span class="avatar"> <img src="images/profile-thumbnail/user.png" class="dker profile-pic2"></span>
										<?php } ?>
									 </div>
									  <div  class="col-sm-11">
									   <div class="row"> <div  class="col-sm-12">
									   <span class="header" >
											<span class="notification-name">
										    	<?php echo ucwords(wordwrap($noti_from_name,16));?> 
										     </span>
											 <span class="message">
                                            <?php echo substr($rec_noti['noti_msg'],0,25);?>
                                        </span> 
											  	
										
										</span>
									   
									   </div></div>
									    <div class="row"><div  class="col-sm-12">
										 <span class="time">
										    	<?php echo $elapsed_notification_time;?>
									   </span>
										
										</div> </div>
									   
									   
									  
									  </div>
									 </div>
									
									
									
									
									
									
									
									
									
									
									
									      	 										
                                </li>
							
							 
							
							   <?php  } ?>
							
								 <div class="ajax-load text-center" style="display:none">  <p><img src="images/loader.gif">Loading More Notifications</p>
										</div>
							  	 
							</ul>
						 
					</div>
				</div><!--/col-->	
				<div class="col-sm-3"></div>
               </div>				
					
					        
	                   
					   
					    
								 
					 
								
							 
								  
								
								 
								
								 
								
								 
						 
					 
				</div><!--/col-->
			
			</div><!--/row-->

			</form>
			
			
		
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>	
	
		<?php  include("resources/templates/script.php"); ?>
	 <script type="text/javascript">
	 
	    $(window).scroll(function() {
        if($(window).scrollTop() + $(window).height() >= $(document).height()) {
            var last_id = $(".notificationsli:last").attr("id");
			//alert(last_id);
            loadMoreData(last_id);
        }
    });
	
function loadMoreData(v){
   
	$(".ajax-load").show();
	$.post("resources/ajax/load-more-data.php",{varload_notifications:v},function (data){
		  //alert(data);
		$(".ajax-load").hide();
		$(".notification-dtls").append(data);
	})
}
                  
 


</script>


</body>
</html>
