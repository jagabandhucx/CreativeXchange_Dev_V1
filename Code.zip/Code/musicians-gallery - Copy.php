 <?php 
include("resources/includes/functions.php");
checkLogin();
$title="My profile ";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 	 

$name=$result['name'];			 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		 
	
	<style>
.default{
 
height: 28px !important;
border-radius:3px;
}
 
 .col-sm-3{
padding-left:0px;
padding-right:2px;
}

	 .img-thumbnail:hover {
    
     -ms-transform: scale(1.5);
    -moz-transform: scale(1.2);
    -webkit-transform: scale(1.2);
    -o-transform: scale(1.2);
    transform: scale(1.5);
	border-radius:2px;
	z-index:99;
	position:relative;
	 
 
}

 
</style>	
		
		 
</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>		
	<!-- start: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
		 <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!--<a id="main-menu-toggle" class="hidden-xs open"><i class="fa fa-bars"></i></a>-->
			<!-- end: Main Menu -->

			
			<!-- start: Content -->
			<div id="content" class="col-sm-10">
			
				<!---<div class="box-content" style="height:70px;">-->
				 
				
							<form class="form-horizontal" >	
			 
							   <div class="form-group" style="width:48%; float:right;">
									<!---<label class="control-label" for="selectError1">Multiple Select / Tags</label>-->
									<div class="controls">
									  <select id="selectError1" class="form-control" multiple data-rel="chosen" style="height:30px;">
									  
							  <?php
							   $query_cate="select * from profession_items where  profession_id='2' ";
							   $sql_cate = $dbh->prepare($query_cate);
							   $sql_cate->execute();
							   while($rec_cate = $sql_cate->fetch(PDO::FETCH_ASSOC))
							   {
								   $uid=$rec_cate['id'];
							   ?>
										<option value="<?php  echo $rec_cate['id'];?>"><?php  echo $rec_cate['name'];?></option>
										
										
							 <?php } ?>
									  </select>
									</div>
								  </div>				  
								  
 
								  <input type="text" class="form-control" id="inputSuccess" style="width:48%;border-radius:0px;" placeholder="Enter Location.">				 
								 
						 
						</form>
						 
						<!--</div>-->
						<form name="musicians" id="musiciansform" method="post" action="musician-gallery.php">
                         <input type="hidden" name="musicianid" id="musicianid" value="" />

                       </form>						
			  
			   
		
			<div class="row sortable">
				<div class="col-lg-12" style="z-index:0;">
					<div class="box">
						
						<div class="box-content" style="background-color:#000;">
							
							<div class="row">
							
							 <?php
							   $query_p="select id,name,profile from user_register where  user_type='1' and professionid='2' and status='1'";
							   $sql_p = $dbh->prepare($query_p);
							   $sql_p->execute();
							   while($rec_p = $sql_p->fetch(PDO::FETCH_ASSOC))
							   {
								   $uid=$rec_p['id'];
								    if($rec_p['profile']!=''){
										$img=$rec_p['profile'];
										}
										else{$img='a2.png';}
							   ?>
							
								<div style="margin-bottom:30px;" class="col-sm-3 col-xs-6 clsoverlay1">
									<a href="#" onclick="redirectUser(<?php echo $uid;?>)" ><img class="img-thumbnail" src="images/profile/
									<?php echo $img; ?>" alt="<?php echo $rec_p['name']; ?>" title="<?php echo $rec_p['name']; ?>" style="min-width: 100%;"></a>
									<span class="innerheading"><i class="fa fa-star"></i>
									<i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i>								
									
									</span>
									 <div class="overlay">
								<a href="#"  onclick="redirectUser(<?php echo $uid;?>)" class="text" style="text-decoration:none;">Show Profile</a>
	  
								</div>					
								</div> 
							   <?php  } ?>
						
 
							</div>
						</div>	
					</div><!--/col-->
				</div><!--/col-->
			
			</div><!--/row-->

    
					
			</div>
			<!-- end: Content -->
			
			<!-- start: Widgets Area -->
 
<!-- end: Widgets Area -->

<!--<a id="widgets-area-button" class="hidden-sm hidden-xs open"><i class="fa fa-bars"></i></a>-->				
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>
	
<?php  include("resources/templates/script.php"); ?>
<script>
function redirectUser(v){
	$("#musicianid").val(v);
	$("#musiciansform").submit();
}

</script>
</body>
</html>