<?php

$hostname='localhost';
$username='root';

$password='';

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=artist",$username,$password);
    //echo 'Connected to Database<br/>';
    }
catch(PDOException $e)
    {
    echo $e->getMessage();
    }


?>