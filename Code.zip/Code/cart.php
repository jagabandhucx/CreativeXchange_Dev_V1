 <?php
include("resources/includes/functions.php");
checkLogin();
$title='Merchanidse';
$id=$_SESSION["user"];

$user_type=$_SESSION["utype"];
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
$name=$result['name'];


/*code for ratings*/			 
if(!isset($_SESSION['user_id'])){
  $_SESSION['user_id'] = $id;
}
			 
require_once __DIR__ . "/config.php";

	/*code for ratings end*/
?> 
 <!DOCTYPE html>
<html lang="en">
<head>
	
<?php  include("resources/templates/head.php"); ?>	
	 
	
	<style>
.default{
 
height: 28px !important;
border-radius:3px;
}
</style>	
		
	<style>
.col-sm-3{
padding-left:0px;
padding-right:2px;
}
.row{
margin-left:0px;
margin-right:0px;
}
 	
 
 
 

	</style>
			
 
		 	
</head>

<body>
<div class="se-pre-con"></div>
		<!-- start: Header -->
<?php  include("resources/templates/header.php"); ?>	
	<!-- start: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
<?php  include("resources/templates/left-menu.php"); ?>	
			
			<!-- end: Main Menu -->

			<!-- start: Content -->
			<div id="content" class="col-sm-12" style="z-index:0;">

			<div class="row sortable">
				<div class="col-lg-1"></div>
				<div class="col-lg-10">
					<div class="box"  >



									<div class="row cartheading">
									 <div class="col-lg-12 ">
									 	 <div class="col-lg-3">Product</div>
									 	  <div class="col-lg-3">Price </div>
									 	   <div class="col-lg-3">Quantity</div>
									 	    <div class="col-lg-3">Total</div>
									 	     

									 </div>
									</div>
											  
									<div class="row cartprodrow">
									 <div class="col-lg-12 ">
								 

											  <div class="col-lg-3 col-sm-4 col-xs-6 "  >
													 <img class="img-thumbnail" src="images/products/1.jpg"  style="width: 90px;"
													  data-image="images/profile/1.jpg" data-gallery='gallery' data-desc='Title'  > 
													  
														&nbsp;&nbsp;&nbsp;&nbsp;<span class="galleryname">Casual T-Shirt</span>
												</div>	
											   
											     
												 <div class="col-lg-3 col-sm-4 col-xs-6">$240</div>
												  <div class="col-lg-3 col-sm-4 col-xs-6"><input type="number" name="qnty[]"  class="cartqntyTxt" value="2" /></div>
												   <div class="col-lg-3 col-sm-4 col-xs-6"><span style="margin-right: 60px;">$480</span>  <button class="btn btn-mini btn-success createevent" type="button" style="height: 32px;"> x</button> </div>
									 
									
									</div>	

	 							</div>		


									<div class="row cartprodrow">
									 <div class="col-lg-12 ">
								 

											  <div class="col-lg-3 col-sm-4 col-xs-6 "  >
													 <img class="img-thumbnail" src="images/products/2.jpg"  style="width: 90px;"
													  data-image="images/profile/3.jpg" data-gallery='gallery' data-desc='Title'  > 
													  
														&nbsp;&nbsp;&nbsp;&nbsp;Casual T-Shirt
												</div>	
											   
											     
												 <div class="col-lg-3 col-sm-4 col-xs-6">$240</div>
												  <div class="col-lg-3 col-sm-4 col-xs-6"><input type="number" name="qnty[]" class="cartqntyTxt" value="3"  /></div>
												   <div class="col-lg-3 col-sm-4 col-xs-6"><span style="margin-right: 60px;">$480</span>  <button class="btn btn-mini btn-success createevent" type="button" style="height: 32px;"> x</button> </div>
									 
									
									</div>	

	 							</div>


	 							<div class="row" style="padding-top: 20px;">
									 <div class="col-lg-12 ">
									 	 <div class="col-lg-6"><input type="text" name="couponcode" id="couponcode" placeholder="Coupon Code" /> &nbsp;&nbsp; <button class="btn btn-mini btn-success createevent" type="button"  > Apply Coupon</button></div>
									 	  
									 	   <div class="col-lg-3"> </div>
									 	    <div class="col-lg-3"> <button class="btn btn-mini btn-success createevent" type="button"  > Update Cart</button></div>
									 	     

									 </div>
									</div>	
									<br>
	 
	                          <div class="row" >
									 <div class="col-lg-12 ">
									 	 <div class="col-lg-6"> <span  style="font-size: 20px; font-weight: 400;">Cart Totals</span></div>
									 	  
									 	   <div class="col-lg-3"> </div>
									 	    <div class="col-lg-3"> </div>
									 	     

									 </div>
									</div>	
	 							
							      <div class="row" >
									 <div class="col-lg-6 carttotaltext"  >
									 	 <div class="col-lg-1"></div>
									 	   <div class="col-lg-4">  <span> Subtotal </span></div>
									 	   <div class="col-lg-3">$400 </div>
									 	    <div class="col-lg-2"> </div>
									 	     

									 </div>

									  <div class="col-lg-6" ></div>

									</div>	
	 						

	 						 <div class="row" >
									 <div class="col-lg-6 carttotaltext"   >
									 	 <div class="col-lg-1"></div>
									 	   <div class="col-lg-4">  <span  > Shipping </span></div>
									 	   <div class="col-lg-5"> Flat Rate  $20 </div>
									 	    <div class="col-lg-2"> </div>
									 	     

									 </div>

									  <div class="col-lg-6" ></div>

									</div>	
	 


	 						 <div class="row" >
									 <div class="col-lg-6 carttotaltext"  style="border-bottom: 1px solid #ddd;" >
									 	 <div class="col-lg-1"></div>
									 	   <div class="col-lg-4">  <span > Total </span></div>
									 	   <div class="col-lg-3">$500</div>
									 	    <div class="col-lg-2"> </div>
									 	     

									 </div>

									  <div class="col-lg-6" ></div>

									</div>	
	 						<br>

	 					<div class="row" >
									 <div class="col-lg-6"   >
									 	 
									 	   
									 	<button class="btn btn-mini btn-success createevent" type="button"   style="width: 100%;"> Proceed to checkout</button>     

									 </div>

									  <div class="col-lg-6" ></div>

									</div>	
	 


															
															
						 	
					</div><!--/col-->
				</div><!--/col-->
			<div class="col-lg-1"></div>
			</div><!--/row-->
 
					
			</div>
			<!-- end: Content -->
 
 			
				</div><!--/row-->
 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 <?php  include("resources/templates/footer.php"); ?>		
	


 
	<?php  include("resources/templates/script.php"); ?>	
 
	 
	  
	 
 <script>
  

	//paste this code under head tag or in a seperate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
 
 
 
</script>

 

</body>

</html>