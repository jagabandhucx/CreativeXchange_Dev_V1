<?php
include("resources/includes/functions.php");
checkLogin();
$title='My Gallery';
$id=$_SESSION["user"];
$date=date("Y-m-d");
$user_type=$_SESSION["utype"];
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
$name=$result['name'];


/*code for ratings*/			 
if(!isset($_SESSION['user_id'])){
  $_SESSION['user_id'] = $id;
}
			 
require_once __DIR__ . "/config.php";

	/*code for ratings end*/
?> 
 <!DOCTYPE html>
<html lang="en">
<head>
	
<?php  include("resources/templates/head.php"); ?>	
	 
	
 	
		
	<style>
.col-sm-3{
padding-left:0px;
padding-right:2px;
}
.row{
margin-left:0px;
margin-right:0px;
}
 
//below code for slider 
ul{
			list-style: none outside none;
		    padding-left: 0;
            margin: 0;
		}
        .demo .item{
            margin-bottom: 5px;
        }
		 
		.content-slider h3 {
		    margin: 0;
		    padding: 70px 0;
		}
		.demo{
			width: 100%;
		}
		
		
		.title{		     
    
    font-family: bo;
    font-size: 22px;
	margin-left:2%;
	margin-bottom:2px;
	cursor:pointer;
   }
 
#content-slider{
	height:290px !important;
	
}		

//Modal-backdrop class is used for ratings popup.
.modal-backdrop{
	display:none;
}	

#watermark{
    // position:absolute;
    z-index:0;
    
    display:block;
    min-height:50%; 
    // min-width:50%;
    color:yellow;
	position: absolute;
   bottom: -9%;
	 
	 
}

#watermark #watermark-text
{    opacity:0.8;
    color:#fff;
    font-size:15px;
    transform:rotate(45deg);
    -webkit-transform:rotate(300deg);
	font-weight: 600;
	border: 1px solid;
    padding-left: 4px;
	border-radius: 2px;
}
	</style>
			
 
		 	
</head>

<body>
<div class="se-pre-con"></div>
		<!-- start: Header -->
<?php  include("resources/templates/header.php"); ?>	
	<!-- start: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
<?php  include("resources/templates/left-menu.php"); ?>	
			
			<!-- end: Main Menu -->
 


<form name="musicians" id="musiciansform" method="post" action="musician-gallery.php">
                         <input type="hidden" name="q" id="q2" value="" />

                       </form>	
					   
<form name="photographerform" id="photographerform" method="post" action="show-photographer-gallery.php">
                         <input type="hidden" name="q" id="q" value="" />

                       </form>	
 		
		
		
			<!-- start: Content -->
	<div id="content" class="col-sm-12" style="z-index:0;">
									
	    	<div class="row sortable">
				<div class="col-lg-12">
					<div class="box">
						
						 <div class="row home-category-txt">
						 <div style="margin-bottom:20px;" class="col-lg-11"> <div class="artistcate-title">What's happening</div></div>
						  <div style="margin-bottom:20px; padding-top:20px;" class="col-lg-1"><a href="photographers-gallery.php">See All >> </a></div>
						 </div>
					  
									<div class="row">
									 <!--<div class="col-lg-12">-->
									<?php
									   
											  $sql_whappening_photographer="select u.name,u.profile,u.id,e.location,e.profession_id,e.event_type from user_register u INNER JOIN events e on u.id=e.assigned_to where '$date'  BETWEEN e.date_from AND e.date_to and e.event_cate='public'";											   
											   $res_whappening_photographer = $dbh->prepare($sql_whappening_photographer);
											   $res_whappening_photographer->execute();
											   
											    
											?>
									
									<div class="demo">
										 
										<div class="item">
											<ul   class="content-slider-whatshappening" >
											   
											   <?php
											   
											   while($rec_wh_photographer = $res_whappening_photographer->fetch(PDO::FETCH_ASSOC))
											   {
															 $uid=$rec_wh_photographer['id'];
																   if($rec_wh_photographer['profile']!=''){
																		$img=$rec_wh_photographer['profile'];
																		}
																		else{$img='galleryProfilePic.png';}
																		$star->id = $uid;
																		 
																		 
																									 
																 
											   ?>

											   <li>
													<img class="img-thumbnail" src="images/profile/<?php echo $img;?>"  style="height:110px;width: 120px;"
													  data-image="images/profile/<?php echo $img;?>" data-gallery='gallery' data-desc='<?php echo ucwords($rec_pic['name']);?>'  onclick="redirectUser(<?php echo $uid;?>)">
													
													  <div class="row">
																	 <div > <span class="gallery-name"><?php echo ucwords(substr($rec_wh_photographer['name'],0,10));?> <span></div>	
																	  <div> <span class="gallery-address">
																	  <?php 
																	  if($rec_wh_photographer['profession_id']==1){
																	  ?>
											   Taking picture in a <?php echo substr($rec_wh_photographer['event_type'],0,12); if(strlen($rec_wh_photographer['event_type'])>12){ echo ".."; } ?> at <?php echo substr($rec_wh_photographer['location'],0,12); }else if($rec_wh_photographer['profession_id']==2){ ?>  Playing in a <?php echo substr($rec_wh_photographer['event_type'],0,12);  if(strlen($rec_wh_photographer['event_type'])>12){ echo ".."; } ?> at <?php echo $rec_wh_photographer['location']; } ?>
											   
																		  </span>
																	  </div> 
																	 
																	  
																	   
																	   <?php echo     $star->getRating("size-4",'html','user'); ?> 	 							  
																</div>	
														
												</li>
											   
											   <?php
											   }
											   ?>
											   
											   
												  <?php
											   $sql_whppening_photo_video="select u.name,u.id,u.profile,s.id,s.type,s.user_id from user_register u INNER JOIN store s on u.id=s.user_id where cast(s.date as date)='$date'";
											   
											  $res_whppening_photo_video = $dbh->prepare($sql_whppening_photo_video);
											   $res_whppening_photo_video->execute();
											   
											   while($rec_whppening_photo_video = $res_whppening_photo_video->fetch(PDO::FETCH_ASSOC))
											   {
															 $uid=$rec_whppening_photo_video['id'];
																   if($rec_whppening_photo_video['profile']!=''){
																		$img=$rec_whppening_photo_video['profile'];
																		}
																		else{$img='galleryProfilePic.png';}
																		$star->id = $uid;
																		 
																		 
																									 
																 
											   ?>

											   <li>
													<img class="img-thumbnail" src="images/profile/<?php echo $img;?>"  style="height:110px;width: 120px;" 
													  data-image="images/profile/<?php echo $img;?>" data-gallery='gallery' data-desc='<?php echo ucwords($rec_whppening_photo_video['name']);?>'  onclick="redirectUser(<?php echo $uid;?>)">
													
													  <div class="row">
																	 <div > <span class="gallery-name"><?php echo ucwords(substr($rec_whppening_photo_video['name'],0,10));?> <span></div>	
																	  <div > <span class="gallery-address">
																	  <?php 
																	  if($rec_whppening_photo_video['type']=='photo'){
																	  ?>
											   Uploaded portfolio photos  <?php }else if($rec_whppening_photo_video['type']=='video'){ ?>  Uploaded portfolio videos  <?php } ?>
											   
																		  </span>
																	  </div> 
																	 
																	  
																	   
																	   <?php echo     $star->getRating("size-4",'html','user'); ?> 	 							  
																</div>	
														
												</li>
											   
											   <?php
											   }
											   ?>
											   
											   
											   
											   
											   
											    <?php
											   $sql_whppening_profile="select name,id,profile  from user_register  where cast(modified as date)='$date'";
											   
											  $res_whppening_profile = $dbh->prepare($sql_whppening_profile);
											   $res_whppening_profile->execute();
											   
											   while($rec_whppening_profile = $res_whppening_profile->fetch(PDO::FETCH_ASSOC))
											   {
															 $uid=$rec_whppening_profile['id'];
																   if($rec_whppening_profile['profile']!=''){
																		$img=$rec_whppening_profile['profile'];
																		}
																		else{$img='galleryProfilePic.png';}
																		$star->id = $uid;
																		 
																		 
																									 
																 
											   ?>

											   <li>
													<img class="img-thumbnail" src="images/profile/<?php echo $img;?>" style="height:110px;width: 120px;"  
													  data-image="images/profile/<?php echo $img;?>" data-gallery='gallery' data-desc='<?php echo ucwords($rec_whppening_profile['name']);?>'  onclick="redirectUser(<?php echo $uid;?>)">
													
													  <div class="row">
																	 <div > <span class="gallery-name"><?php echo ucwords(substr($rec_whppening_profile['name'],0,15));?> <span></div>	
																	  <div > <span class="gallery-address">
																	   Updated profile
																		  </span>
																	  </div> 
																	 
																	  
																	   
																	   <?php echo     $star->getRating("size-4",'html','user'); ?> 	 							  
																</div>	
														
												</li>
											   
											   <?php
											   }
											   ?>
												
												  
											</ul>
										</div>						

									</div>	
									 
									
								<!---</div>-->	

 							</div>		
	 
															
															
						 	
					</div><!--/col-->
				</div><!--/col-->
			
			</div><!--/row-->
	     
	
			 
				<div class="row sortable">
				<div class="col-lg-12">
					<div class="box">
						
						 <div class="row home-category-txt">
						 <div style="margin-bottom:20px;" class="col-lg-11"> <div class="artistcate-title">Photographers</div></div>
						  <div style="margin-bottom:20px; padding-top:20px;" class="col-lg-1"><a href="photographers-gallery.php">See All >> </a></div>
						 </div>
					  
									<div class="row">
									 <!--<div class="col-lg-12">-->
									<?php
									  $query="select id,name,profile,address,city,state,country,price from user_register where  user_type='1' and professionid='1' and status='1'";
											   $sql = $dbh->prepare($query);
											   $sql->execute();
											   //echo $sql->rowCount();
											   if($sql->rowCount()>0){ 
											   
												   
											?>
									
									<div class="demo">
										 
										<div class="item">
											<ul   class="content-slider" >
											   
											   <?php
											   
											   while($rec_pic = $sql->fetch(PDO::FETCH_ASSOC))
											   {
															 $uid=$rec_pic['id'];
																   if($rec_pic['profile']!=''){
																		$img=$rec_pic['profile'];
																		}
																		else{$img='galleryProfilePic.png';}
																		$star->id = $uid;
																		 
																		// Get city and state name
																		$city=$rec_pic['city'];
														  $query_city="select city from cities where id='$city'";
														 $res_city = $dbh->prepare($query_city);
														 $res_city->execute();	
														 $rec_city= $res_city->fetch(PDO::FETCH_ASSOC); 
														 
														 if(isset($rec_pic['state']) && $rec_pic['state']!=''){
															 $state=$rec_pic['state'];
															 $query_state="select state from states where state_code='$state'";
														 $res_state = $dbh->prepare($query_state);
														 $res_state->execute();	
														 $rec_state= $res_state->fetch(PDO::FETCH_ASSOC); 
														 } 
														 
														    if(isset($rec_pic['country']) && $rec_pic['country']!=''){
						  
															  $countryid=$rec_pic['country'];
															  $query_country="select nicename from country where id='$countryid'";
															 $res_country = $dbh->prepare($query_country);
															 $res_country->execute();	
															 $rec_country= $res_country->fetch(PDO::FETCH_ASSOC); 
															 
														   }
																									 
																 
											   ?>

											   <li>
													<img class="img-thumbnail" src="images/profile/<?php echo $img;?>"  style="height:190px;width: 295px;"
													  data-image="images/profile/<?php echo $img;?>" data-gallery='gallery' data-desc='<?php echo ucwords($rec_pic['name']);?>'  onclick="redirectUser(<?php echo $uid;?>)">
													
													  <div class="row">
																	 <div > <span class="gallery-name"><?php echo ucwords($rec_pic['name']);?> <span></div>	
																	  <div > <span class="gallery-address">
																		<?php //if(isset($rec_pic['address']) && $rec_pic['address']!=''){echo $rec_pic['address'].",";}?>  <?php if(isset($rec_pic['city']) && $rec_pic['city']!=''){echo $rec_city['city'].",";}?><?php if(isset($rec_pic['state']) && $rec_pic['state']!=''){echo $rec_state['state'].",";}?><?php if(isset($rec_pic['country'])){echo $rec_country['nicename'];}?></span>
																	  </div> 
																	 
																	  <?php 
																	  if($rec_pic['price']!='' && $rec_pic['price']!=0){
																	  ?>																	  
																	   <!--<div > <span class="gallery-price">   <i class="fa fa-dollar"></i> <?php echo $rec_pic['price']; ?> per hour</span></div>-->	
																	  <?php } ?>
																	   
																	   <?php echo     $star->getRating("size-4",'html','user'); ?> 	 							  
																</div>	
														
												</li>
											   
											   <?php
											   }
											   ?>
											   
											   
												 
												
												  
											</ul>
										</div>						

									</div>	
									 <?php
									} else{
										?>
										
										<div style="margin-left: 2%;margin-top: 10px;margin-bottom: 10px;"> No Content</div>
										<?php  		
										
										}
								   ?>
									
								<!---</div>-->	

 							</div>		
	 
															
															
						 	
					</div><!--/col-->
				</div><!--/col-->
			
			</div><!--/row-->

    
		<div class="row sortable">
				<div class="col-lg-12">
					<div class="box">
						
						 <div class="row home-category-txt">
						 <div style="margin-bottom:20px;" class="col-lg-11"> <div class="artistcate-title">Musicians</div></div>
						  <div style="margin-bottom:20px; padding-top:20px;" class="col-lg-1"><a href="musicians-gallery.php">See All >> </a></div>
						 </div>
					  
									<div class="row">
									 <div class="col-lg-12">
									<?php
									  $query="select id,name,profile,address,city,state,country,price,trainer from user_register where  user_type='1' and professionid='2' and status='1'";
											   $sql = $dbh->prepare($query);
											   $sql->execute();
											   //echo $sql->rowCount();
											   if($sql->rowCount()>0){ 
											   
												   
									?>
									
									<div class="demo">
										 
										<div class="item">
											<ul   class="content-slider" >
											   
											   <?php
											   
											   while($rec_pic = $sql->fetch(PDO::FETCH_ASSOC))
											   {
															 $uid=$rec_pic['id'];
																   if($rec_pic['profile']!=''){
																		$img=$rec_pic['profile'];
																		}
																		else{$img='galleryProfilePic.png';}
																		$star->id = $uid;
																		 
																		// Get city and state name
																		$city=$rec_pic['city'];
														  $query_city="select city from cities where id='$city'";
														 $res_city = $dbh->prepare($query_city);
														 $res_city->execute();	
														 $rec_city= $res_city->fetch(PDO::FETCH_ASSOC); 
														 
														 if(isset($rec_pic['state']) && $rec_pic['state']!=''){
															 $state=$rec_pic['state'];
															 $query_state="select state from states where state_code='$state'";
														 $res_state = $dbh->prepare($query_state);
														 $res_state->execute();	
														 $rec_state= $res_state->fetch(PDO::FETCH_ASSOC); 
														 }    
															
														if(isset($rec_pic['country']) && $rec_pic['country']!=''){
						  
															  $countryid=$rec_pic['country'];
															  $query_country="select nicename from country where id='$countryid'";
															 $res_country = $dbh->prepare($query_country);
															 $res_country->execute();	
															 $rec_country= $res_country->fetch(PDO::FETCH_ASSOC); 
															 
														   }															
																 
											   ?>

											   <li>
													<img class="img-thumbnail" src="images/profile/<?php echo $img;?>"  style="height:190px;width: 295px;"
													  data-image="images/profile/<?php echo $img;?>" data-gallery='gallery' data-desc='<?php echo ucwords($rec_pic['name']);?>'  onclick="redirectUser2(<?php echo $uid;?>)">
													  <?php 
													  if($rec_pic['trainer']!='yes'){
													  ?>
													     <span id="watermark">
															<label id="watermark-text">  Trainer  &nbsp;&nbsp;  </label>
														</span>
													<?php } ?>
													  <div class="row">
																	 <div> <span class="gallery-name"><?php echo ucwords($rec_pic['name']);?> <span></div>	
																	  <div> <span class="gallery-address">
																		<?php //if(isset($rec_pic['address']) && $rec_pic['address']!=''){echo $rec_pic['address'].",";}?>  <?php if(isset($rec_pic['city']) && $rec_pic['city']!=''){echo $rec_city['city'].",";}?><?php if(isset($rec_pic['state']) && $rec_pic['state']!=''){echo $rec_state['state'].",";}?><?php if(isset($rec_pic['country'])){echo $rec_country['nicename'];}?></span>
																	  </div> 
																	<?php 
																	  if($rec_pic['price']!='' && $rec_pic['price']!=0){
																	  ?>																	  
																	  <!-- <div > <span class="gallery-price">   <i class="fa fa-dollar"></i> <?php echo $rec_pic['price']; ?> per hour</span></div>	--->
																	  <?php } ?>
																	
																	
																	
																	  <?php echo     $star->getRating("size-4",'html','user'); ?> 							  
																</div>	
														
												</li>
											   
											   <?php
											   }
											   ?>
											   
											   
												 
												
												  
											</ul>
										</div>						

									</div>	
									 <?php
									} else{
										?>
										
										<div style="margin-left: 2%;margin-top: 10px;margin-bottom: 10px;"> No Content</div>
										<?php  		
										
										}
								   ?>
									
								</div>	

 							</div>		
	 
															
										 
 											
						 	
					</div><!--/col-->
				</div><!--/col-->
			
			</div><!--/row-->
	
	
	
	
	
	
					
			</div>
			<!-- end: Content -->
			
 

 			
				</div><!--/row-->
		
		 


    
  
		
	</div><!--/container-->
	
		<!-- Code for ratings---->
		<?php
	/*	echo $get_past_events="select e.id,e.event_type,e.date_to,e.created_by,e.assigned_to from events e INNER JOIN user_register u on e.created_by=u.id where e.created_by='$id' and e.payment_status='1' and e.date_to<'$date'";
		$res_past_events=$dbh->prepare($get_past_events);		 
		$res_past_events->execute();
		if($res_past_events->rowCount()>){
			while($rec_past_events=$res_past_events->fetch(PDO::FETCH_ASSOC)){
				$get_eventid=$rec_past_events['id'];
				$get_assignedtoid=$rec_past_events['assigned_to'];
				$check_review_tbl="select * from reviews where rate_id='$get_eventid' and user_id='$id' ";
				$res_review_tbl=$dbh->prepare($check_review_tbl);
				$res_review_tbl->execute();
				if()
				
			}
		}*/

		
		?>
		<!---<div class="modal fade" id="myModal">
			<div class="modal-dialog">
			<form action="" name="ratingsform" id="ratingsform" method="post">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title">Rate   </h4>
					</div>
					<div class="modal-body">
					
					 <div>  <?php echo     $star->getRating("userChoose size-3",'html','event'); ?>  </div> <br>
					 <div><textarea   cols="70" placeholder="Your feedback and comments.." style="height:70px;" name="txtReviews" id="txtReviews" ></textarea></div><br>
					
						
						 
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary btn-success" onclick="funRate(<?php echo $message_receiverid; ?>)">Save changes</button>
					</div>
				</div> 
				</form>
			</div> 
		</div> -->
		
									<script>
									var slidertotalitem=4;
									</script>  	
		
	
	<div class="clearfix"></div>
	
 <?php  include("resources/templates/footer.php"); ?>		
	


 
	<?php  include("resources/templates/script.php"); ?>	
	<script src="assets/js/photographer-gallery.js"></script>
	
	
	 
 <script>
  

	//paste this code under head tag or in a seperate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
 
	
 		$('.profile-pic').grumble(
			{
				text: 'Click here to show menu', 
				angle: 200, 
				distance: 0, 
				type: 'alt-', 
				showAfter: 500,
				hideAfter:3000
			}
		);
	
 
 
 
 
 
 
	
function redirectUser(v){
	$("#q").val(v);
	$("#photographerform").submit();
}

function redirectUser2(v){
	$("#q2").val(v);
	$("#musiciansform").submit();
}

$(document).ready(function() {
  // notificationFunc();
  
 // notificationFunc2();
	//$('#myModal').modal('show');
  setTimeout(notificationFunc2 , 3000);
 setTimeout(notificationFunc , 5000);

 
	
	
})

function notificationFunc(){
		$.gritter.add({
			// (string | mandatory) the heading of the notification
			title: 'Complete your profile!',
			// (string | mandatory) the text inside the notification
			text: 'Please update your profile to get the good trafic <br><i class="fa fa-hand-o-right"></i>  <a href="profile.php" style="color:#ffffff">Go to my profile</a> .'
		});

		return false;
}

function notificationFunc2(){
		$.gritter.add({
			// (string | mandatory) the heading of the notification
			title: 'Rate the event!',
			// (string | mandatory) the text inside the notification
			text: 'Please rate the last event  <br> <i class="fa fa-hand-o-right"></i> <a href="orders.php" style="color:#ffffff">Go to event page</a> .'
		});

		return false;
}
</script>

 

</body>

</html>