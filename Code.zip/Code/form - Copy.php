<?php
include("resources/includes/functions.php");
checkLogin();
 
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
if($user_type==1){
$sql_orders="select e.*,u.name,u.profile from events e left join user_register u on e.created_by=u.id  where e.assigned_to='$id' order by e.id desc";

}else if($user_type==2){
$sql_orders="select e.*,u.name,u.profile from events e left join user_register u on e.created_by=u.id  where e.created_by='$id' order by e.id desc";	
}
$res_orders=$dbh->prepare($sql_orders);
$res_orders->execute();
?>
<?php  include("resources/templates/head.php"); ?>	
<style>
/* Using panels to display blog date */
.panel.date {
    margin: 0px;
    width: 60px;
    text-align: center;
}

.panel.date .month {
    padding: 2px 0px;
    font-weight: 700;
    text-transform: uppercase;
}

.panel.date .day {
    padding: 3px 0px;
    font-weight: 700;
    font-size: 1.5em;
}

</style>
<div class="wrap-embed-contact-form">
	<form class="embed-contact-form">
		 
		 
		 
		<div class="form-content">
			 
			 <!-- Container, Row, and Column used for illustration purposes -->
 
	<div class="row">
		 <div class="col-lg-12">
        
            <!-- Fluid width widget -->        
    	    <div class="panel panel-danger">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span class="glyphicon glyphicon-calendar"></span> 
                        Upcoming Events
                    </h3>
                </div>
                <div class="panel-body">
                    <ul class="media-list">
					<?php
					 while($rec_orders = $res_orders->fetch(PDO::FETCH_ASSOC))
							   {
								   $date_noti=$rec_orders['date_from'];
								   $elapsed_notification_time=time_elapsed_string($date_noti);
								   $eventid=$rec_orders['id'];
								   $monthNum  = date("m",strtotime($date_noti));
									$dateObj   = DateTime::createFromFormat('!m', $monthNum);
									$monthName = $dateObj->format('M'); 
					?>
					
                        <li class="media">
						<div class="col-lg-4">
                            <div class="media-left">
                                <div class="panel panel-danger text-center date">
                                    <div class="panel-heading month">
                                        <span class="panel-title strong">
                                            <?php echo $monthName; ?>
                                        </span>
                                    </div>
                                    <div class="panel-body day text-danger">
                                        <?php echo date("d",strtotime($date_noti));?>
                                    </div>
                                </div>
                            </div>
							</div>
							<div class="col-lg-8">
                            <div class="media-body">
                                <h4 class="media-heading">
                                    <?php echo ucwords($rec_orders['event_type']);?>
                                </h4>
                                <p>
                                    <?php echo ucwords($rec_orders['location']);?>
                                </p>
                            </div>
							</div>
                        </li>
						
					 <?php  } ?>
						
						
					
                         
                    </ul>
                    <a href="orders.php" class="btn btn-default btn-block">More Events »</a>
                </div>
            </div>
            <!-- End fluid width widget --> 
            
		</div>
	</div>

			 
			 
			 
		</div>events2
		<a class="btn-show-contact" href="#contact"><img src="assets/img/events2.png" style="width:52px; height:180px;"></a>
	</form>
</div>

	<?php  include("resources/templates/script.php"); ?>