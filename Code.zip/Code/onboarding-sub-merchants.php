<?php 
include("resources/includes/functions.php");
checkLogin();
$title="Onboarding Sub-merchants";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
 
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
			 

$query_state="select * from states";
$sql_state = $dbh->prepare($query_state);
             $sql_state->execute();
             	 


$query_cities="select * from cities";
$sql_cities = $dbh->prepare($query_cities);
             $sql_cities->execute();

	
$query_profession="select * from professions where id='$result[professionid]'";
$sql_profession = $dbh->prepare($query_profession);
 $sql_profession->execute();	
$rec_profession_name= $sql_profession->fetch(PDO::FETCH_ASSOC); 
	//echo $rec_profession_name['name'];	 

$name=$result['name'];	





?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		
<style>
#message{
text-align: center;
font-size: 18px;
background-color: #ebf8a4;
color: #000;
border-radius: 2px;
border:1px solid #a2d246;
}
.form-control{
	border-right: #fff;	
}




</style>


</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
			  <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->


			<!-- start: Content -->
			<div id="content" class="col-sm-12">
			
			<form name="submerchant-form" id="submerchant-form" method="post" action="onboarding-sub-merchants-action.php">
			 
		 
			<div class="row" >		
				<div class="col-lg-12">
					<div class="box">
					<div style="text-align:center;"> <h1 style="font-weight: 400;color: #4267b2;">  Create Sub Merchant Account </h1></div>	
					
					          <div class="row" id="showmessage"  style="display:none;">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										  <div class="row" id="message" >	</div>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
					
	                   
					   
					   
					   	<div class="row">		
								<div class="form-group"  >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused" id="firstName" name="firstName"   type="text" placeholder="Name" 
										 value="<?php if(isset($name)  && $name!=''){ echo $name; } ?>" required>
									  <span class="input-group-addon"><i class="fa fa-user"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
					   
					   
					   
					 
					 	<div class="row">		
								<div class="form-group"  >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused" id="email" name="email"   type="email" placeholder="Email"  value="<?php if(isset($result['email'])  && $result['email']!=''){ echo $result['email']; } ?>" required >
									  <span class="input-group-addon"><i class="fa fa-info"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
							
							
							 	<div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused" id="phone" name="phone"   type="text" placeholder="Phone" value="<?php if(isset($result['phone'])  && $result['phone']!=''){ echo $result['phone']; } ?>" required>
									  <span class="input-group-addon"><i class="fa fa-phone"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								
								
								<?php 
								if(isset($result['dob']) && $result['dob']!=''){
									$dob=$result['dob'];
									$vardob=explode("-",$dob);
									$dobyear=$vardob[0];
									$dobmonth=$vardob[1];
									$dobday=$vardob[2];
									
								} ?>
								
								
						  	<div class="row">		
								<div class="form-group"  >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
								    <div class="col-sm-4">
									         <select id="dobmonth" name="dobmonth" class="form-control" style="width:100px;border: 1px solid #E5E5E4;" data-rel="chosen">								  
									    
											<option value="" selected> Month</option>
												<option value="01"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==01){?>  selected <?php } ?>> January</option>
												<option value="02"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==02){?>  selected <?php } ?> > February</option>
												<option value="03"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==03){?>  selected <?php } ?> > March</option>
												<option value="04"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==04){?>  selected <?php } ?> > April</option>
												<option value="05"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==05){?>  selected <?php } ?> > May</option>
												<option value="06"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==06){?>  selected <?php } ?> > June</option>
												<option value="07"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==07){?>  selected <?php } ?> > July</option>
												<option value="08"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==08){?>  selected <?php } ?> > August</option>
												<option value="09"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==09){?>  selected <?php } ?> > September</option>
												<option value="10"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==10){?>  selected <?php } ?> > October</option>
												<option value="11"    <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==11){?>  selected <?php } ?> > November</option>
												<option value="12"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==12){?>  selected <?php } ?> > December</option>										 
												 </select>
									   
									   
									   
									   </div>
								  
									 <div class="col-sm-4"> 
									    <select id="dobday" name="dobday" class="form-control" style="width:100px;border: 1px solid #E5E5E4;" data-rel="chosen">						  
									    
												<option value="" selected> Day</option>
												<option value="01"   <?php if(isset($dobday) && $dobday!='' && $dobday==01){?>  selected <?php } ?> > 01</option>
												<option value="02" <?php if(isset($dobday) && $dobday!='' && $dobday==02){?>  selected <?php } ?> > 02</option>
												<option value="03" <?php if(isset($dobday) && $dobday!='' && $dobday==03){?>  selected <?php } ?> > 03</option>
												<option value="04" <?php if(isset($dobday) && $dobday!='' && $dobday==04){?>  selected <?php } ?> > 04</option>
												<option value="05" <?php if(isset($dobday) && $dobday!='' && $dobday==05){?>  selected <?php } ?> > 05</option>
												<option value="06"  <?php if(isset($dobday) && $dobday!='' && $dobday==06){?>  selected <?php } ?> > 06</option>
												<option value="07" <?php if(isset($dobday) && $dobday!='' && $dobday==07){?>  selected <?php } ?> > 07</option>
												<option value="08" <?php if(isset($dobday) && $dobday!='' && $dobday==08){?>  selected <?php } ?> > 08</option>
												<option value="09" <?php if(isset($dobday) && $dobday!='' && $dobday==09){?>  selected <?php } ?> > 09</option>
												<option value="10" <?php if(isset($dobday) && $dobday!='' && $dobday==10){?>  selected <?php } ?> > 10</option>
												<?php for($i=11; $i<31; $i++){  ?>
												<option value="<?php echo $i; ?>"  <?php if(isset($dobday) && $dobday!='' && $dobday==$i){?>  selected <?php } ?>> <?php echo $i; ?></option>
												<?php } ?>
												 							 
												 </select>
									 </div>
									  <div class="col-sm-4"> 
									       <select id="dobyear" name="dobyear" class="form-control" style="width:100px;border: 1px solid #E5E5E4;" data-rel="chosen">								  
									    
												<option value="" selected> Year</option>
												
											<?php for($i=1960; $i<2001; $i++){  ?>
												<option value="<?php echo $i; ?>"   <?php if(isset($dobyear) && $dobyear!='' && $dobyear==$i){?>  selected <?php } ?> > <?php echo $i; ?></option>
												<?php } ?>
												 						 
												 </select>
									  </div>
									   
									 
									 
									 
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								 
								 	<div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group  col-sm-12">
										
										 <input class="form-control" id="ssn" name="ssn"   type="text" placeholder="Ssn" value="<?php if(isset($result['ssn'])  && $result['ssn']!=''){ echo $result['ssn']; } ?>"  >
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								
								
									<div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused" id="account_number" name="account_number"   type="text" placeholder="Account Number" required  
										 value="<?php if(isset($result['account_no'])  && $result['account_no']!=0){ echo $result['account_no']; } ?>" >
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								
								<div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused" id="routing_number" name="routing_number"   type="text" placeholder="Routing Number" required 
										 value="<?php if(isset($result['routing_no'])  && $result['routing_no']!=''){ echo $result['routing_no']; } ?>" >
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								
								
								 
								 
								 
								 
								 
								 
					 
								
								 
								<div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										   <button class="btn btn-mini btn-success chpassword" type="submit"  >Submit</button>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								 
								 
								 	 
								 
								
								 
								
								 
						 
					</div>
				</div><!--/col-->
			
			</div><!--/row-->

			</form>
			
			
			
			
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>	
	
		<?php  include("resources/templates/script.php"); ?>
	 <script type="text/javascript">
	 
	                  
 

function changePassword(){
	
	 var current_password=$("#current_password").val();
	  var new_password=$("#new_password").val();
	   var confirm_password=$("#confirm_password").val();
	   
	   
	 
	$.post("resources/ajax/ajax.php",{varcurrent_password:current_password,varnew_password:new_password,varconfirm_password:confirm_password},function (data){
		alert(data);
		  
		if(data==1){
			
			$("#showmessage").show();
			$("#message").html("Password Changeed Successfully.");
					 
		}else if(data==2){
			$("#showmessage").show();
			$("#message").html("Current Password is Wrong.");
			
		}
			
		
	})
	
}
</script>


</body>
</html>
