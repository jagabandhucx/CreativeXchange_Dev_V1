<?php
$hostname='52.36.246.127';
$username='root';
$password='Art1sN#tw0rk';

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=artist",$username,$password);
    //echo 'Connected to Database<br/>';
    }
catch(PDOException $e)
    {
    echo $e->getMessage();
    }


?>