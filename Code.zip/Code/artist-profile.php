<?php 
/*include("resources/includes/functions.php");
checkLogin();
$title="My profile ";
$id=$_SESSION["user"];
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); */
			 

$query_state="select * from states";
$sql_state = $dbh->prepare($query_state);
             $sql_state->execute();
             	 


$query_cities="select * from cities";
$sql_cities = $dbh->prepare($query_cities);
             $sql_cities->execute();

	
$query_profession="select * from professions where id='$result[professionid]'";
$sql_profession = $dbh->prepare($query_profession);
 $sql_profession->execute();	
$rec_profession_name= $sql_profession->fetch(PDO::FETCH_ASSOC); 
	//echo $rec_profession_name['name'];	 

$name=$result['name'];


$sql_followers="select count(*) from bookmarks where bookmark_id='$id'";
$res_followers = $dbh->query($sql_followers);
$total_followers=$res_followers->fetchColumn();		

$sql_following="select count(*) from bookmarks where created_by='$id'";
$res_following = $dbh->query($sql_following);
$total_following=$res_following->fetchColumn();	

$sql_events="select count(*) from events where assigned_to='$id'";
$res_events = $dbh->query($sql_events);
$total_events=$res_events->fetchColumn();	
 
/*function countAll($table){
   $dbh = DbConnect();
   $sql = "select * from `$table`";

   $stmt = $dbh->prepare($sql);
    try { $stmt->execute();}
    catch(PDOException $e){echo $e->getMessage();}

return $stmt->rowCount();	 
}*/

 /*code for ratings*/			 
if(!isset($_SESSION['user_id'])){
  $_SESSION['user_id'] = $id;
}
			 
require_once __DIR__ . "/config.php";

	/*code for ratings end*/
?>
 <!DOCTYPE html>
<html lang="en">
<head>
	
<?php  include("resources/templates/head.php"); ?>	
		
<style>
.profile-pic2{
 
border-radius:50%;
border:1px solid #3b3b41;
}


 

.profileheading{
margin-left: 92px;
color: #fff;
font-size: 20px;
font-weight: bold
} 

 
.text-muted{
color:#7cc2ef !important;
}

// #info2 span{
 
// float:left;
// }

#msgrow2{
background-color: #4267b2;
color: #fff;
border-radius: 2px;
padding: 4px 20px;
font-size: 14px;
}

.upload-pic{
	position: absolute;
top: 45px;
left: 28px;
 
color: #000;
font-weight: 600;
cursor: help;
}

 .overlay {
    position: absolute;
   
    left: 0;
    right: 0;
     
     
    overflow: hidden;
    width: 100.2%;
    height: 0;
    transition: .5s ease;
    color: red !important;
    top: 20%;
 }
 

 .chosen-choices input[type="text"] {
    height:50px !important;
}

 #fileInput{
 height: 43px;
 font-size: 18px;
 }
 #filePreview{
	 height:100%;
	 width:100%;
	 
 }
 
  .user-profile-top footer a{
color:#4267b2;	 
	 
 }
 .tab-menu.nav-tabs > li > a{
	 border-top:0;
	 border-left:0;
	 border-right:0;
 }
</style>
  <link href="src/css/style-upcomingevent.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="assets/css/imgareaselect.css" />
</head>

<body>
<div class="se-pre-con"></div>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>	
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
		 
 <?php  include("resources/templates/left-menu.php"); ?>
			<!-- end: Main Menu -->
			
			

			

<div id="myModal" class="modal" style="top:10%;left:15%;">
 <i class="fa fa-times  close2"></i>
  <!-- Modal content -->
  <div class="modal-content" style="width:600px;" >
   <div class="form-group">
				
				<div class="controls"  >
					  <form action="resources/includes/upload-profile.php" enctype="multipart/form-data" id="Uploadprofileform" method="post" onsubmit="return checkCoords();">
								<p> <input name="image" id="fileInput" size="30" type="file" /></p>
								<input type="hidden" id="x" name="x" />
								<input type="hidden" id="y" name="y" />
								<input type="hidden" id="w" name="w" />
								<input type="hidden" id="h" name="h" />
								<button class="btn btn-mini btn-success"  name="upload" type="submit" onclick="priceUpdate()" style="padding:0px 24px;">Upload</button>
							</form>
							<img id="filePreview" style="display:none;width:100%;"/>
							 
				</div>
			</div>	  
 </div>

</div>

<?php if(isset($result['cover_photo']) && $result['cover_photo']!=''){ 
			    $background_image=$result['cover_photo'];
			   }else{
				  $background_image="background.jpg";  
			   }
			   
			   ?> 
			<!-- start: Content -->
			<div id="content" class="col-sm-12">
			<div class="row" >	
					<div class="wrapper user-profile-top" >
                        <section class="panel no-border bg-primary lt" style="background-image: url('images/cover-photo/<?php echo $background_image;?>');" >
                          <div class="panel-body">
                            <div class="row m-t-xl" style="height:200px;">
                              
                              <div class="col-xs-12 text-center">
                                <div class="inline">
                                 
								 
								  <div class="thumb-lg avatar" style="left: 3%; position: absolute;top: 70px;border:1px solid #d3d6db;border-radius:3px;">
									<?php if(isset($result2['profile']) && $result2['profile']!=''){?>
										
										 <img src="images/profile-thumbnail/<?php echo $result2['profile'];?>"   style="height:150px; width:150px;">
										
										<?php } else {?>
                                       <img src="images/profile-thumbnail/default-thumb.png" class="dker profile-pic2">
										<?php } ?>
                                    
	 				
                                  </div>	
                                  
                                </div>
                              </div>
                              <div class="col-xs-2 padder-v">
                                
                              </div>
                            </div>
                            <div class="wrapper m-t-xl m-b">
                              
                            </div>
                          </div>
                         
                        </section>
                      </div>
			</div><!--/row-->
				<?php 
					 
					  if(isset($result['city']) && $result['city']!=''){
						  
						  $city=$result['city'];
						  $query_city="select city from cities where id='$city'";
						 $res_city = $dbh->prepare($query_city);
						 $res_city->execute();	
						 $rec_city= $res_city->fetch(PDO::FETCH_ASSOC); 
						 
						 if(isset($result['state']) && $result['state']!=''){
							 $state=$result['state'];
							 $query_state="select state from states where state_code='$state'";
						 $res_state = $dbh->prepare($query_state);
						 $res_state->execute();	
						 $rec_state= $res_state->fetch(PDO::FETCH_ASSOC); 
						 }
					  }
					  
					  
					   if(isset($result['country']) && $result['country']!=''){
						  
						  $countryid=$result['country'];
						  $query_country="select nicename from country where id='$countryid'";
						 $res_country = $dbh->prepare($query_country);
						 $res_country->execute();	
						 $rec_country= $res_country->fetch(PDO::FETCH_ASSOC); 
						 
					   }
					  
					   $joined_month=date("F",strtotime($result['created']));
					   $joined_year=date("Y",strtotime($result['created']));
					   
					  ?>

			<div class="row  profile-main-content">
			<div class="col-sm-3">
			<div class="row profile-left-cl" style="margin-left:25px;">
			 
			<div class="col-sm-12  text-lt"> <span style="font-weight:600;font-size:21px; "><?php echo ucwords($name); ?></span></div>
			<?php if($result['price']!=''  && $result['price']!=0){  ?>
			<!--<div class="col-sm-12"><i class="fa fa-dollar"></i>   <?php  echo $result['price']; ?> Per hour </div>-->
			<?php } ?>
			<div class="col-sm-12"><i class="fa fa-calendar"></i> Joined <?php echo $joined_month." ".$joined_year; ?></div>
			 
			<div class="col-sm-12"><i class="fa fa-map-marker"></i> 
			 <?php if(isset($result['address']) && $result['address']!=''){echo $result['address'].",";}?>  <?php if(isset($result['city']) && $result['city']!=''){echo $rec_city['city'].",";}?><?php if(isset($result['state']) && $result['state']!=''){echo $rec_state['state'].",";}?><?php if(isset($result['country']) && $result['country']!=''){echo $rec_country['nicename'];}?>
			
			</div>
			<div class="col-sm-12"><a href="account-deactivate.php"><i class="fa fa-trash-o"></i> Delete </a></div>
			<br><br> 
			<!--<div class="col-sm-12" style="color:#4267b2;"> 5 Followers you know</div>
			<div class="col-sm-12"><img src="images/profile-thumbnail/best1.jpg" class="profile-pic"> <img src="images/profile-thumbnail/best2.jpg" class="profile-pic"> <img src="images/profile-thumbnail/best3.jpg" class="profile-pic"> <img src="images/profile-thumbnail/best1.jpg" class="profile-pic"><img src="images/profile-thumbnail/saswat2.jpg" class="profile-pic"></div>-->
			
			
			
			</div>
			</div>
			
			<div class="col-sm-6">
			<div class="box">
						 
					 
							<ul class="nav tab-menu nav-tabs profiletab" id="myTab">
								<li class="active"><a href="profile.php#info2">Edit Profile</a></li>
								<!--<li  ><a href="profile.php#custom">Biography</a></li>
								<li><a href="profile.php#messages">Activities</a></li>-->
								<li><a href="profile.php#following">Following <?php echo $total_following;?></a></li>
								<li><a href="profile.php#followers">Followers <?php echo $total_following;?></a></li>
								<!--<li><a class="active" href="photographer-profile.html#friendsList">Friends 450</a></li>-->
							
							</ul>

							<div id="myTabContent" class="tab-content profile-content" style="margin-top:35px;">
								<div class="tab-pane active" id="info2">
							    
								 
								 

						 
						<form name="register-form"  id="register-form" enctype="form-data" method="post"  action="#" class="form-horizontal">		
								
								 <div class="row">
                                  					  
									<div class="col-sm-12">
									<div class="input-group date col-sm-12">	
											 
											  <input type="text" class="form-control input-border-right-white" id="name" name="name" value="<?php if(isset($result['name'])){echo $result['name'];}?>" >
											   <span class="input-group-addon"> <i class="fa fa-user"></i></span>
											</div>

								   </div>
								  
								</div>
								</br>
								<!--- <div class="row">
                                  
									<div class="col-sm-12">
									  <div class="form-group has-success">
											 
											  <select id="gender" name="gender" class="form-control" style="width:100px;border: 1px solid #E5E5E4;" data-rel="chosen">								  
									    
												<option value="" selected> Gender</option>
												<option value="male"  <?php if(isset($result['gender']) && $result['gender']=='male'){ ?>  selected <?php } ?> > Male</option>
												<option value="female"  <?php if(isset($result['gender']) && $result['gender']=='female'){ ?>  selected <?php } ?>> Female</option>
												<option value="other"   <?php if(isset($result['gender']) && $result['gender']=='other'){ ?>  selected <?php } ?>> Other</option>
												 
												 
											  </select>
											  
											</div>

								   </div>
								   
								</div>--->
								
								<?php 
								// if(isset($result['dob']) && $result['dob']!=''){
									// $dob=$result['dob'];
									// $vardob=explode("-",$dob);
									// $dobyear=$vardob[0];
									// $dobmonth=$vardob[1];
									// $dobday=$vardob[2];
									
								// } ?>
								<!---<div class="row">
                               
									<div class="col-sm-4">
									    <div class="form-group has-success">
											 
											   <select id="dobmonth" name="dobmonth" class="form-control" style="width:100px;border: 1px solid #E5E5E4;" data-rel="chosen">								  
									    
											<option value="" selected> Month</option>
												<option value="01"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==01){?>  selected <?php } ?>> January</option>
												<option value="02"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==02){?>  selected <?php } ?> > February</option>
												<option value="03"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==03){?>  selected <?php } ?> > March</option>
												<option value="04"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==04){?>  selected <?php } ?> > April</option>
												<option value="05"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==05){?>  selected <?php } ?> > May</option>
												<option value="06"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==06){?>  selected <?php } ?> > June</option>
												<option value="07"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==07){?>  selected <?php } ?> > July</option>
												<option value="08"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==08){?>  selected <?php } ?> > August</option>
												<option value="09"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==09){?>  selected <?php } ?> > September</option>
												<option value="10"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==10){?>  selected <?php } ?> > October</option>
												<option value="11"    <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==11){?>  selected <?php } ?> > November</option>
												<option value="12"   <?php if(isset($dobmonth) && $dobmonth!='' && $dobmonth==12){?>  selected <?php } ?> > December</option>										 
												 </select>
											  </div>

								      </div>
									  
									  <div class="col-sm-4">
									    <div class="form-group has-success">
											 
											   <select id="dobday" name="dobday" class="form-control" style="width:100px;border: 1px solid #E5E5E4;" data-rel="chosen">								  
									    
												<option value="" selected> Day</option>
												<option value="01"   <?php if(isset($dobday) && $dobday!='' && $dobday==01){?>  selected <?php } ?> > 01</option>
												<option value="02" <?php if(isset($dobday) && $dobday!='' && $dobday==02){?>  selected <?php } ?> > 02</option>
												<option value="03" <?php if(isset($dobday) && $dobday!='' && $dobday==03){?>  selected <?php } ?> > 03</option>
												<option value="04" <?php if(isset($dobday) && $dobday!='' && $dobday==04){?>  selected <?php } ?> > 04</option>
												<option value="05" <?php if(isset($dobday) && $dobday!='' && $dobday==05){?>  selected <?php } ?> > 05</option>
												<option value="06"  <?php if(isset($dobday) && $dobday!='' && $dobday==06){?>  selected <?php } ?> > 06</option>
												<option value="07" <?php if(isset($dobday) && $dobday!='' && $dobday==07){?>  selected <?php } ?> > 07</option>
												<option value="08" <?php if(isset($dobday) && $dobday!='' && $dobday==08){?>  selected <?php } ?> > 08</option>
												<option value="09" <?php if(isset($dobday) && $dobday!='' && $dobday==09){?>  selected <?php } ?> > 09</option>
												<option value="10" <?php if(isset($dobday) && $dobday!='' && $dobday==10){?>  selected <?php } ?> > 10</option>
												<?php for($i=11; $i<31; $i++){  ?>
												<option value="<?php echo $i; ?>"  <?php if(isset($dobday) && $dobday!='' && $dobday==$i){?>  selected <?php } ?>> <?php echo $i; ?></option>
												<?php } ?>
												 							 
												 </select>
											  </div>

								      </div>
									  
									  <div class="col-sm-4">
									    <div class="form-group has-success">
											 
											   <select id="dobyear" name="dobyear" class="form-control" style="width:100px;border: 1px solid #E5E5E4;" data-rel="chosen">								  
									    
												<option value="" selected> Year</option>
												
											<?php for($i=1960; $i<2001; $i++){  ?>
												<option value="<?php echo $i; ?>"   <?php if(isset($dobyear) && $dobyear!='' && $dobyear==$i){?>  selected <?php } ?> > <?php echo $i; ?></option>
												<?php } ?>
												 						 
												 </select>
											  </div>

								      </div>
									  
								   
								  
								</div>--->
								
								
								
								
								
									<div class="row">
                                  
									<div class="col-sm-12">
									  <div class="form-group ">
											 
											   <select id="profeession" name="profeession" class="form-control" onchange="getProfessionitems(this.value)" data-rel="chosen">						  
									    
										<option value="" > Select your profession</option>
										<option value="1" <?php if($result['professionid']=='1'){?> selected <?php } ?> > Photographer</option>
										<option value="2" <?php if($result['professionid']=='2'){?> selected <?php } ?> > Musician</option>
										 
										 
									  </select>
											</div>
								   </div>
								  
								</div>
								
								
								<?php 
								
								if($result['professionid']!='' && $result['professionid']=='1'){
									
											$style1="display:block;";
										
								}
								else{
									$style1="display:none;";
								}
								
								if($result['professionid']!='' && $result['professionid']=='2'){
										
											$style2="display:block;";
										
								}
								else{
									$style2="display:none;";
								}
								?>
								<div class="row" id="photographertypee" style="<?php echo $style1;?>">                                 							 
								   				   
									<div class="col-sm-12">
									  <div class="form-group has-success">
											 
									   <select id="account_type_p" name="account_type_p" class="form-control"  data-rel="chosen">						  
									    
										<option value="" > Select Account Type</option>
										<option value="Personal" <?php if($result['account_type']=='Personal'){ ?> selected <?php } ?> > Personal</option>
										<option value="Organization" <?php if($result['account_type']=='Organization'){ ?> selected <?php } ?> > Organization </option>										 
										 
									  </select>
									</div>
								   </div>
								   
								</div>	
								
								<div class="row" id="musiciantypee" style="<?php echo $style2;?>">                                 							 
								   				   
									<div class="col-sm-12">
									  <div class="form-group has-success">
											 
									   <select id="account_type_m" name="account_type_m" class="form-control"  data-rel="chosen">						  
									    
										<option value="" > Select Account Type</option>
										<option value="Solo" <?php if($result['account_type']=='Solo'){ ?> selected <?php } ?> > Solo</option>
										<option value="Band" <?php if($result['account_type']=='Band'){ ?> selected <?php } ?> > Band </option>										 
										 
									  </select>
									</div>
								   </div>
								   
								</div>	
								
								
								
								
								 <div class="row" style="<?php echo $style1;?>" id="professiondtlrow">
								 					 
								   
					   <?php
					                        $professionitems=explode(",",$result['professiondtl_id']);
											//print_r($professionitems);
											$query_profession_items="select * from profession_items where profession_id='1'";
											$sql_profession_items = $dbh->prepare($query_profession_items);
										    $sql_profession_items->execute();	
					   ?>
									<div class="col-sm-12">
									<div class="form-group">
									
									<div class="controls">
									    <select data-placeholder="Click here to select the category" multiple class="chosen-select"  style="width:100%;" id="profeession-dtl1" data-rel="chosen">
											<option value=""></option>
											 
											<?php
																					 
										while($result_subcat = $sql_profession_items->fetch(PDO::FETCH_ASSOC)){
											 
										?>
										<option value="<?php echo $result_subcat['id']; ?>" 
										<?php if(in_array($result_subcat['id'],$professionitems)){?> selected <?php } ?> > <?php echo $result_subcat['name']; ?></option>
										 
										<?php } ?>
											 
					             		</select>
									</div>
								    </div>
								   </div>
								  
								 </div>
								 
								 
								 
								 
								 
								  <div class="row" style="<?php echo $style2;?>" id="professiondtlrow2">
							 
									<div class="col-sm-12">
									<div class="form-group">
									
									<div class="controls">
									    <select data-placeholder="Specialization" multiple class="chosen-select"  style="width:100%;height:52px;" id="profeession-dtl2" data-rel="chosen">
											<option value=""></option>
											 
											<?php
											$varprofession_subcate=explode(",",$result['professiondtl_id']);
											$query_profession_items="select * from profession_items where profession_id='2'";
											$sql_profession_items = $dbh->prepare($query_profession_items);
										    $sql_profession_items->execute();	
											
										while($result_subcat = $sql_profession_items->fetch(PDO::FETCH_ASSOC)){
										?>
										<option value="<?php echo $result_subcat['id']; ?>" 
										<?php if(in_array($result_subcat['id'],$varprofession_subcate)){?> selected <?php } ?> > <?php echo $result_subcat['name']; ?></option>
										 
										<?php } ?>
											 
					             		</select>
									</div>
								    </div>
								   </div>
								 
								 </div>
								 
								
								
								
								
								<?php if(isset($result['venues']) && $result['venues']!=''){
									$venues=explode(",",$result['venues']);
									// print_r($venues);
									
								}								
								?>
								
								 
								  <div class="row" style="<?php echo $style2;?>"  id="venues">
							 
									<div class="col-sm-12">
									<div class="form-group">
									
									<div class="controls">
									    <select data-placeholder="Venues" multiple class="chosen-select"  style="width:100%;height:52px;" id="venues" name="venues" data-rel="chosen">
											<option value="Cafe" <?php  if(isset($result['venues']) && $result['venues']!='' && in_array('Cafe',$venues)){?> selected <?php } ?>>Cafe</option>
											<option value="Bars" <?php  if(isset($result['venues']) && $result['venues']!='' && in_array('Bars',$venues)){?> selected <?php } ?>>Bars</option>
											<option value="Restaurants" <?php  if(isset($result['venues']) && $result['venues']!='' && in_array('Restaurants',$venues)){?> selected <?php } ?>>Restaurants</option>
											<option value="Corporate Events" <?php  if(isset($result['venues']) && $result['venues']!='' && in_array('Corporate Events',$venues)){?> selected <?php } ?>>Corporate Events</option>		
					             		</select>
									</div>
								    </div>
								   </div>
								 
								 </div>
								 
								  
								 
								  <div class="row" style="<?php echo $style2;?>" id="trainer">
								 
									<div class="col-sm-12">
									<div class="form-group">
									
									<div class="controls">
									      <div class="input-group date col-sm-12">
											   Are you a trainer ?  &nbsp; &nbsp; Yes <input type="radio" name="trainer"  value="yes"  <?php  if(isset($result['trainer']) && $result['trainer']!='' && $result['trainer']=='yes'){?> checked <?php } ?> />  &nbsp; &nbsp;No <input type="radio" name="trainer"  value="no"  <?php  if(isset($result['trainer']) && $result['trainer']!='' && $result['trainer']=='no'){ ?> checked <?php } ?> />										 
											   
											</div>								 
										 
									</div>
								    </div>
								   </div>
								  
								 </div>
							 
								<div class="row">
                                   
									<div class="col-sm-12">
									  <div class="form-group">
											  <div class="input-group date col-sm-12">
											  <input type="text" class="form-control input-border-right-white" id="email" value="<?php if(isset($result['email'])){echo $result['email'];}?>"  readonly placeholder="Email">
											    <span class="input-group-addon"> <i class="fa fa-envelope-o"></i></span>
											</div>
											</div>
								   </div>
								   
								</div>
								
								<!---<div class="row">
                               							 
								    
					   
									<div class="col-sm-12">
									  <div class="form-group">
											  <div class="input-group date col-sm-12">
											   <input type="text" class="form-control input-border-right-white" id="price" name="price" value="<?php if(isset($result['price']) && $result['price']!=0 ){echo $result['price'];}?>"  placeholder="Rate Per Hour" >
											  
											     <span class="input-group-addon">  <i class="fa fa-dollar"></i> </span>
											   
											</div>
											</div>
								   </div>
								   
								   
								 
								</div>--->
								

								<?php
								 $query_country="select * from country";
								 $res_country = $dbh->prepare($query_country);
											 $res_country->execute();
								?>
								
								<div class="row">
                                 
									<div class="col-sm-4">
									
									<div class="form-group">
									 
									<div class="controls">
									  <select id="country" name="country" class="form-control" data-rel="chosen" onChange="funCountry(this.value)">								  
									    
										 
									    <option value="">Select Country</option>
										<?php
										while($rec_country = $res_country->fetch(PDO::FETCH_ASSOC)){
											 if(isset($result['country']) && $result['country']!=''){
										?>
										<option value="<?php echo $rec_country['id']; ?>" 
										<?php if($rec_country['id']==$result['country']){  ?> selected <?php } ?> > <?php echo $rec_country['name']; ?></option>
										 
										<?php }
											else { ?>
												<option value="<?php echo $rec_country['id']; ?>" 
										<?php if($rec_country['id']==226){  ?> selected <?php } ?> > <?php echo $rec_country['name']; ?></option>
												
											<?php }
										}

										?>
										 
										 
									  </select>
									</div>
								  </div>
								  
								   </div>
								   
								   <div class="col-sm-4">
									
									<div class="form-group">
									 
									<div class="controls">
									  <select id="state" name="state" class="form-control" onChange="getCities(this.value)" data-rel="chosen">
									  
									    <option value="">Select State</option>
										<?php
										while($result_state = $sql_state->fetch(PDO::FETCH_ASSOC)){
										?>
										<option value="<?php echo $result_state['state_code']; ?>" 
										<?php if($result['state']==$result_state['state_code']){?> selected <?php } ?> > <?php echo $result_state['state']; ?></option>
										 
										<?php } ?>
									  </select>
									</div>
								  </div>
								  
								   </div>
								   
								   
								    <?php
					    $query_cities="select * from cities where state_code='$result[state]'";
             $sql_cities = $dbh->prepare($query_cities);
             $sql_cities->execute();
			/* $result_city = $sql_cities->fetch(PDO::FETCH_ASSOC); 
			 $cityname=$result_city['city'];*/
					   ?>
									<div class="col-sm-4">
									
									<div class="form-group">
									 
									<div class="controls" id="citydiv">
									  <select id="city" name="city" class="form-control" data-rel="chosen">
									  
									    <option value="">Select City</option>
										<?php
										/*if(isset($cityname) && $cityname!=''){
											?>
										<option value="<?php echo $cityname;?>" selected ><?php echo $cityname;?></option>
										<?php
										}*/
										while($result_city = $sql_cities->fetch(PDO::FETCH_ASSOC)){
										?>
										<option value="<?php echo $result_city['id']; ?>" <?php if($result['city']==$result_city['id']){?> selected <?php } ?>> <?php echo $result_city['city']; ?></option>
										 
										<?php }  ?>
										 
										 
									  </select>
									</div>
								  </div>
								  
								   </div>
								   
								  	
								</div>
								
							 
								 
								
								
								
								<div class="row">
                                  
									<div class="col-sm-12">
									  <div class="form-group">
											  <div class="input-group col-sm-12"> 
											   <input type="text" class="form-control input-border-right-white" id="address" name="address" value="<?php echo $result['address'];?>"  placeholder="Address">
												<span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
											</div>
											</div>
								   </div>
								  
								</div>
								
								
								<div class="row">
                                 
					   
									<div class="col-sm-6">
									  <div class="form-group">
											   <div class="input-group col-sm-12">
											   <input type="text" class="form-control input-border-right-white" id="phone" name="phone" value="<?php if(isset($result['phone'])){echo $result['phone'];}?>"  placeholder="Phone">
											   	<span class="input-group-addon"><i class="fa fa-phone"></i></span>
											</div>
											</div>
								   </div>
								   
								   <div class="col-sm-6">
									  <div class="form-group">
											 	 <div class="input-group col-sm-12">
											  <input type="text" class="form-control input-border-right-white" id="account_no" name="account_no" value="<?php if(isset($result['account_no'])){echo $result['account_no'];}?>"  placeholder="Account no">
											  	<span class="input-group-addon"><i class="fa fa-lock"></i></span>
											</div>
											</div>
								   </div>
								 
								</div>
								
								<input type="hidden" name="uid" id="uid" value="<?php echo $id;?>"/>
								 
								<div class="row">
                               
									<div class="col-sm-12">
									  <div class="form-group has-success">
											   <label> Biography</label>
											    <!-- <input type="text"  class="form-control"  style="width: 100%; height: 70px; " name="bio" id="bio" placeholder="Bio"  value=" <?php if(isset($result['bio'])){echo $result['bio'];}?>"/>--->
												
												<textarea class="cleditor"   rows="2" name="bio" id="bio"><?php if(isset($result['bio'])){echo $result['bio'];}?></textarea>
											   	
											</div>
								   </div>
								  
								</div>
								
								</br>
								<div class="row">
                                 
					   
									<div class="col-sm-12">
									  <div class="form-group has-success">
											   <label> Activity</label>
											  <!-- <input   type="text"  class="form-control"  name="activity" id="activity" placeholder="Activities"   style="width: 100%; height: 70px; " value="<?php if(isset($result['activity'])){echo $result['activity'];}?>"/>--->
											  	<textarea class="cleditor"   rows="2" name="activity" id="activity"  ><?php if(isset($result['activity'])){echo $result['activity'];}?></textarea>
											  
											</div>
								   </div>
								  
								</div>
								</br>
								<!--<div class="row" style="display:none;" id="msgrow">
                                   <div   class="col-sm-3"></div>								 
								   
					   
									<div class="col-sm-6" id="msgrow2">
									  
								   </div>
								   <div   class="col-sm-3"></div>	
								</div>
								</br>-->
								
								
								
								
								<div class="row">
                               
					   
									<div class="col-sm-12">
									  <div class="form-group has-success">
											  
													 <button class="btn btn-mini btn-success chpassword" onClick="updateUserInfo()" type="button">Update Profile</button>
											
											</div>
								   </div>
								 
								</div>
								
								

								</form>
 
								</div>
								<div class="tab-pane" id="custom">
									<p>
										 <?php if(isset($result['bio'])){echo $result['bio'];}?> 
									</p>
									
									
								</div>
								<div class="tab-pane" id="messages">
									<p>
										
										 <?php if(isset($result['activity'])){echo $result['activity'];}?>
									</p>
									
									
								</div>
								<div class="tab-pane" id="following">
								 <div class="row">
									  <div class="col-lg-12">
								
								      
					                    <div class="box friendlistdiv">
						                   
								 <?php
								  $sql="select * from bookmarks where created_by='$id'";
								   $sql_b= $dbh->prepare($sql);
								   $sql_b->execute();
								   if($sql_b->rowCount()>0){
								   while($rec_b = $sql_b->fetch(PDO::FETCH_ASSOC))
								   {
								   $bid=$rec_b['bookmark_id'];  
								   $query_p="select id,name,profile,professionid from user_register where  id='$bid'";
								   $sql_p = $dbh->prepare($query_p);
								   $sql_p->execute();
								   $rec_p = $sql_p->fetch(PDO::FETCH_ASSOC);
							   
								   $uid=$rec_p['id'];
								   if($rec_p['profile']!=''){
										$img=$rec_p['profile'];
										}
										else{$img='a2.png';} 
										
										//chk count for earch user
								   $sql_followup="select count(*) from bookmarks where created_by='$uid'";
								   $res_followup= $dbh->prepare($sql_followup);
								   $res_followup->execute();
								   $varfollowing_count=$res_followup->fetchColumn(); 
								   $redirecturl="profile.php?qa=".base64_encode($uid);
								   $star->id = $uid;
										?>
						
								  <div class="col-sm-6">
								  <ul class="tickets" >
									
									<li class="ticket" >
										<a href="#">
											 
											<span class="content">
												<span class="avatar"><img src="images/profile-thumbnail/<?php echo $img; ?>" alt="Avatar" class="profilePicList"></span>
												<span class="name  nameflist" onclick="redirectUser('<?php echo $redirecturl;  ?>')"><?php echo ucwords($rec_p['name']); ?></span>
												 
												<span class="status flwcnt" ><?php echo $varfollowing_count;?> Following</span></br>
												<span class="status" ><?php echo     $star->getRating("userChoose size-4",'html','user'); ?></span>
												 <!--<button class="btnFriends date"><i class="fa fa-star-o"></i> <lable>Following</label></button>-->
											</span>	                                                        
										</a>
									</li>
									
									</ul>
									</div>
												
							   <?php }
							   
								   }else{?>
									  <div style="text-align:center;"><h1> Not Following Anyone</h1></div> 
								  <?php }
							   
							   ?>		
												
												
												
												</div>
											  
											  
											
											 </div>
									     </div>
									
								</div>
								
								
								<div class="tab-pane" id="followers">
								 <div class="row">
									  <div class="col-lg-12">
								
								      
					                    <div class="box friendlistdiv">
						                   
								 <?php
								  $sql="select * from bookmarks where created_by='$id'";
								   $sql_b= $dbh->prepare($sql);
								   $sql_b->execute();
								   if($sql_b->rowCount()>0){
								   while($rec_b = $sql_b->fetch(PDO::FETCH_ASSOC))
								   {
								   $bid=$rec_b['bookmark_id'];  
								   $query_p="select id,name,profile,professionid from user_register where  id='$bid'";
								   $sql_p = $dbh->prepare($query_p);
								   $sql_p->execute();
								   $rec_p = $sql_p->fetch(PDO::FETCH_ASSOC);
							   
								   $uid=$rec_p['id'];
								   if($rec_p['profile']!=''){
										$img=$rec_p['profile'];
										}
										else{$img='a2.png';} 
										
										//chk count for earch user
								   $sql_followup="select count(*) from bookmarks where created_by='$uid'";
								   $res_followup= $dbh->prepare($sql_followup);
								   $res_followup->execute();
								   $varfollowing_count=$res_followup->fetchColumn(); 
								   $redirecturl="profile.php?qa=".base64_encode($uid);
								   $star->id = $uid;
										?>
						
								  <div class="col-sm-6">
								  <ul class="tickets" >
									
									<li class="ticket" >
										<a href="#">
											 
											<span class="content">
												<span class="avatar"><img src="images/profile-thumbnail/<?php echo $img; ?>" alt="Avatar" class="profilePicList"></span>
												<span class="name  nameflist" onclick="redirectUser('<?php echo $redirecturl;  ?>')"><?php echo ucwords($rec_p['name']); ?></span>
												 
												<span class="status flwcnt" ><?php echo $varfollowing_count;?> Following</span></br>
												<span class="status" ><?php echo     $star->getRating("userChoose size-4",'html','user'); ?></span>
												 <!--<button class="btnFriends date"><i class="fa fa-star-o"></i> <lable>Following</label></button>-->
											</span>	                                                        
										</a>
									</li>
									
									</ul>
									</div>
												
							   <?php }
							   
								   }else{?>
									  <div style="text-align:center;"><h1> Not Following Anyone</h1></div> 
								  <?php }
							   
							   ?>		
												
												
												
												</div>
											  
											  
											
											 </div>
									     </div>
									
								</div>
								 
								
								
							</div>
						 
					</div>
			</div>
			
	<div class="col-sm-3">

					<div class="row topratedcol" style="margin-left:5px;">
			
			<div class="col-sm-12  text-lt"> <span style="font-weight:600;font-size:21px;margin-left: 10px; ">  Top Rated Creatives</span></div>
			 
			<br><br> 
			 
			  <?php
		 $sql_top_performer="SELECT u.name,u.professionid,u.profile,r.rate_id,SUM(r.rate)/COUNT(*) as rates FROM ratings r INNER JOIN user_register u on r.rate_id=u.id where r.type='user' GROUP by r.`rate_id` order by rates desc LIMIT 10";
		
		 $res_top_performer= $dbh->prepare($sql_top_performer);
								   $res_top_performer->execute();
								   if($res_top_performer->rowCount()>0){
								   while($rec_top_performer = $res_top_performer->fetch(PDO::FETCH_ASSOC))
								   {
									   $top_ratedid=$rec_top_performer['rate_id'];
		?>
		
		
			
		
			<div class="col-sm-12">
					<div class="row">	
					<div class="col-sm-3">
				<?php if(isset($rec_top_performer['profile']) && $rec_top_performer['profile']!=''){ ?>
				
				<a href=""> <img src="images/profile-thumbnail/<?php echo $rec_top_performer['profile'];?>"  class="profile-pic2"/> </a>
				
				<?php } else { ?>
			  <a href=""> <img src="images/profile-thumbnail/user.png" class="dker profile-pic2"> </a>
				<?php } ?>
				</div>
				<div class="col-sm-9">
				<div class="row">	<div class="col-sm-12">
				 <a href="" class="topratedname">	<?php echo ucwords($rec_top_performer['name']);  ?></a>
				  <div class="topratedartisttype"><?php if($rec_top_performer['professionid']==1){ echo "Photographer";}else if($rec_top_performer['professionid']==2){ echo "Musician"; } ?> </div>
				 </div>
				</div>
				<div class="row">	
				<div  id="toprated<?php  echo $top_ratedid; ?>" class="col-sm-12">  
				 <?php
						 $query_bookmarks="select * from bookmarks where created_by ='$id' and bookmark_id='$top_ratedid'";
						 $res_bookmarks = $dbh->prepare($query_bookmarks);
						 $res_bookmarks->execute();
						if($res_bookmarks->rowCount()>0){?>
						<a href="#" onclick="removebookmarkArtist(<?php echo $top_ratedid;?>)" title="Unfollow" class="following"> Following</i> </a>
						<?php } else{						 ?>
						
						  <a href="#" onclick="bookmarkArtist(<?php echo $top_ratedid;?>)" title="Follow" class="follow"> Follow</a>
						<?php }?>
						
				</div>
				</div>
				</div>
				</div>
				
				
			</div>
			
					<?php
					
				   }
				}
					
					?>
			
			
			
			</div>




		</div>
			
			
			</div>
			
			
			
			
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	<?php  include("resources/templates/footer.php"); ?>	
 
	<!-- start: JavaScript-->
	<?php  include("resources/templates/script.php"); ?>
	<!-- inline scripts related to this page -->

	  <script src="assets/js/charts/easypiechart/jquery.easy-pie-chart.js"></script>
	   <script src="assets/js/app.plugin.js"></script>
	   <script src="assets/js/jquery.cleditor.min.js"></script>
	  <!-- <script src="assets/js/dropzoneprofile.min.js"></script>-->
	  <script type="text/javascript" src="assets/js/jquery.imgareaselect.js"></script>
	   	<script type="text/javascript">
			// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");
	});
	
		
$(function(){
  $('.searchTerm').on("focus blur", function(){   
   // $(this).parent().toggleClass("expanded collapsed");
     $(this).siblings('.suggestionBox').toggle();
    });
	
	
});

function updateUserInfo(){

   var name=$("#name").val();
   var cpassword=$("#password").val();
   var npassword=$("#cpassword").val();
   var phone=$("#phone").val();
   var account=$("#account_no").val();
   var bio=$("#bio").val();
   var activity=$("#activity").val();
   var uid=$("#uid").val();
   var country=$("#country").val();
   var state=$("#state").val();
   var city=$("#city").val();
   var address=$("#address").val();
    var gender=$("#gender").val();
	 var dobyear=$("#dobyear").val();
	 var dobmonth=$("#dobmonth").val();
	 var dobday=$("#dobday").val();
	  var venues=$("#venues").val();
	   var price=$("#price").val();
	 var dob=dobyear+"-"+dobmonth+"-"+dobday;
   var profeession=$("#profeession").val();
   if(profeession==1){
	   var profeessiondtl=$("#profeession-dtl1").val();
   }else if(profeession==2){
	   var profeessiondtl=$("#profeession-dtl2").val();
   }else{
	   var profeessiondtl="";
   }
  var solo=$('#solo').is(':checked'); 
   var band=$('#band').is(':checked'); 
   var trainer_status=$("input[name=trainer]:checked").val();
   if(profeession==1){
	 var account_type=$("#account_type_p").val(); //photographer  
   }else if(profeession==2){
	var account_type=$("#account_type_m").val(); //musician  
   }  
	 
   
    $.post("resources/ajax/register-ajax.php",{varname:name,varcpassword:cpassword,varnpassword:npassword,varphone:phone,varaccount:account,varbio:bio,varactivity:activity,varuid:uid,varstate:state,varcountry:country,varcity:city,varaddress:address,varprofeession:profeession,varprofeessiondtl:profeessiondtl,vargender:gender,vardob:dob,varvenues:venues,varprice:price,varsolo:solo,varband:band,vartrainer_status:trainer_status,varaccount_type:account_type}, function(data) {
       //alert(data);
	   if(data==2){
		   $("#msgrow").show();
		   $("#msgrow2").html('Entered password is wrong');
		   
	   }
	   if(data==1){
		    $("#msgrow").show();
		   $("#msgrow2").html('Updated successfully.');
		   window.location.href="index.php";
		   
	   }
	   
    });

    return false;
 
	
}


function getCities(val){
	
	 $.post("resources/ajax/register-ajax.php",{varstatename:val},function (data){
		 
		 $("#citydiv").html(data);
	 });
	
}

function getProfessionitems(val){
	
	if(val==1){
		 $("#professiondtlrow2").hide();
		 $("#professiondtlrow").show();
		  $("#photographertypee").show();
		   $("#musiciantypee").hide();
		    $("#venues").hide();
			 $("#trainer").hide();
		
	}
	
	if(val==2){
		 $("#professiondtlrow").hide();
		 $("#professiondtlrow2").show();
		 $("#photographertypee").hide();
		 $("#musiciantypee").show();
		 $("#venues").show();
		 $("#trainer").show();
	}
	
	/* $.post("resources/ajax/register-ajax.php",{varprofessionitesm:val},function (data){
		 
		 $("#professiondtl").html(data);
		  $("#professiondtlrow").show();
		   $("#professiondtlrow").html(data);
	 });
	*/
}


 
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close2")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
 
 
 $(document).ready(function(){
	 
	   $('textarea').each(function(){
            $(this).val($(this).val().trim());
        }
    );
   
});


function redirectUser(url){
	
	window.location=url;
}

 
//set image coordinates
function updateCoords(im,obj){
	$('#x').val(obj.x1);
	$('#y').val(obj.y1);
	$('#w').val(obj.width);
	$('#h').val(obj.height);
}

//check coordinates
function checkCoords(){
	if(parseInt($('#w').val())) return true;
	alert('Please select a crop region then press submit.');
	return false;
}

$(document).ready(function(){
	//prepare instant image preview
	var p = $("#filePreview");
	$("#fileInput").change(function(){
		//fadeOut or hide preview
		p.fadeOut();

		//prepare HTML5 FileReader
		var oFReader = new FileReader();
		oFReader.readAsDataURL(document.getElementById("fileInput").files[0]);

		oFReader.onload = function (oFREvent) {
			p.attr('src', oFREvent.target.result).fadeIn();
		};
	});

	//implement imgAreaSelect plugin
	$('img#filePreview').imgAreaSelect({
		onSelectEnd: updateCoords
	});
});



  	function  bookmarkArtist(v){
		 
		$.post("resources/ajax/event-action.php",{varbookmarkid:v},function (data){
			// obj=JSON.parse(data);
			 
			 $("#toprated"+v).html(data);
				/*if(obj[0]==1){
						alert("Bookmarked successfullly.");
				}else if(obj[0]==2){
						alert("You have already bookmarked on "+ obj[1]);
				}else if(obj[0]==0){
						alert("Failed");
				}*/
		})
		
	}
	
	function  removebookmarkArtist(v){
		 
		$.post("resources/ajax/event-action.php",{varremovebookmarkid:v},function (data){
			 
			 //alert(data);
			$("#toprated"+v).html(data);
				 
		})
		
	}
</script>


</body>
</html>

