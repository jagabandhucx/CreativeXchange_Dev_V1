<?php 
include("resources/includes/functions.php");
checkLogin();
$title="Gallery";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 	 

$name=$result['name'];	
/*code for ratings*/			 
if(!isset($_SESSION['user_id'])){
  $_SESSION['user_id'] = $id;
}
			 
require_once __DIR__ . "/config.php";

/*code for ratings end*/	 		 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		 
	
	<style>
.default{
 
height: 28px !important;
border-radius:3px;
}
 
 .col-sm-3{
padding-left:0px;
padding-right:2px;
}

	 .img-thumbnail:hover {
    
     -ms-transform: scale(1.5);
    -moz-transform: scale(1.3);
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    transform: scale(1.3);
	border-radius:2px;
	z-index:99;
	position:relative;
	 
 
}

 .expplore-artist{
	 height: 70px;
width: 92px;
 }
 .expplorecate{
	 font-size:17px;
	 padding-top: 21px;
     text-align:center;
	font-weight :600;
 }
  .expplorecate a{
	   color:#484848;
	   text-decoration:none;
  }
 .expplorediv{
	 border:1px solid #e4e4e4;
	 padding-left: 0;
 }
 .expplore-pic{
	 float:left;
 }
 
.gallery-name{
	 font-size:17px;
	 font-weight :600;
	  color:#484848;
 }
 .home-category-txt h1{
	 font-weight:600;
 }
</style>	
		
		 
</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>		
	<!-- start: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
		 <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!--<a id="main-menu-toggle" class="hidden-xs open"><i class="fa fa-bars"></i></a>-->
			<!-- end: Main Menu -->

			
			<!-- start: Content -->
			<div id="content" class="col-sm-12">
			
				<!---<div class="box-content" style="height:70px;">-->
				 
				
							<!--<form class="form-horizontal" >	
			 
							   <div class="form-group" style="width:48%; float:right;">
								 
									<div class="controls">
									  <select id="selectError1" class="form-control"  data-rel="chosen" style="height:30px;">
									  
							  <?php
							   $query_cate="select * from profession_items where  profession_id='1' ";
							   $sql_cate = $dbh->prepare($query_cate);
							   $sql_cate->execute();
							   while($rec_cate = $sql_cate->fetch(PDO::FETCH_ASSOC))
							   {
								   $uid=$rec_cate['id'];
							   ?>
										<option value="<?php  echo $rec_cate['id'];?>"><?php  echo $rec_cate['name'];?></option>
										
										
							 <?php } ?>
									  </select>
									</div>
								  </div>				  
								  
 
								  <input type="text" class="form-control" id="inputSuccess" style="width:48%;border-radius:0px;" placeholder="Enter Location.">				 
								 
						 
						</form>--->
						 
						<!--</div>-->
			 
			  <form name="musicians" id="musiciansform" method="post" action="show-photographer-gallery.php">
                         <input type="hidden" name="q" id="q" value="" />

                       </form>	
					   
					   
					   
				<div class="row sortable">
				       <div class="col-lg-12" style="z-index:0;">
					     <div class="box">
						   <div class="col-md-3 col-sm-6 col-xs-12" > 
						      <div class=" col-lg-12 expplorediv">
							   <div class="expplore-pic"><img src="images/profile/whatshappening.jpg" class="expplore-artist"/> </div> 
							   <div class="expplorecate" ><a href="">What's Happening</a> </div>
						   </div>
						   </div>
					   
						  <div class="col-md-3 col-sm-6 col-xs-12" > 
						      <div class=" col-lg-12 expplorediv">
							   <div class="expplore-pic"><img src="images/profile/pgrapher.jpg" class="expplore-artist"/> </div> 
							   <div class="expplorecate" ><a href="gallery.php">Photographers </a></div>
						   </div>
						   </div>
						   
						  <div class="col-md-3 col-sm-6 col-xs-12" > 
						      <div class=" col-lg-12 expplorediv">
							   <div class="expplore-pic"><img src="images/profile/musician-home.jpg" class="expplore-artist"/> </div> 
							   <div class="expplorecate" ><a href="#">Musicians</a> </div>
						   </div>
						   </div>
						 
							 
			   
			           </div>
					  </div>
				 </div>
			   
		
			<div class="row sortable">
				<div class="col-lg-12" style="z-index:0;">
					<div class="box">
						 <div class="row home-category-txt">
						 <div style="margin-bottom:20px;" class="col-lg-11"> <h1>Photographers</h1></div>
						  <div style="margin-bottom:20px; padding-top:5px;" class="col-lg-1"><a href="">See All > </a></div>
						 </div>
					 
							
							<div class="row">
							
							 <?php
							   $query_p="select id,name,profile,address,city,state,country from user_register where  user_type='1' and professionid='1' and status='1'";
							   $sql_p = $dbh->prepare($query_p);
							   $sql_p->execute();
							   while($rec_p = $sql_p->fetch(PDO::FETCH_ASSOC))
							   {
								   $uid=$rec_p['id'];
								   if($rec_p['profile']!=''){
										$img=$rec_p['profile'];
										}
										else{$img='galleryProfilePic.png';}
										$star->id = $uid;
										
										// Get city and state name
										$city=$rec_p['city'];
						  $query_city="select city from cities where id='$city'";
						 $res_city = $dbh->prepare($query_city);
						 $res_city->execute();	
						 $rec_city= $res_city->fetch(PDO::FETCH_ASSOC); 
						 
						 if(isset($rec_p['state']) && $rec_p['state']!=''){
							 $state=$rec_p['state'];
							 $query_state="select state from states where state_code='$state'";
						 $res_state = $dbh->prepare($query_state);
						 $res_state->execute();	
						 $rec_state= $res_state->fetch(PDO::FETCH_ASSOC); 
						 }
							   ?>
							
								<div style="margin-bottom:40px;" class="col-md-3 col-sm-6 col-xs-12 clsoverlay1 ">
									<a href="#" onclick="redirectUser(<?php echo $uid;?>)"><img class="img-thumbnail" src="images/profile/
									<?php echo $img; ?>" alt="<?php echo $rec_p['name']; ?>" title="<?php echo $rec_p['name']; ?>"  style="width:300px; height:200px;"></a>
									 
									 <div class="overlay">
								<a  href="#" onclick="redirectUser(<?php echo $uid;?>)" class="text" style="text-decoration:none;">Show Profile</a>
	  
								</div>	
								<div class="row">
									 <div class="col-lg-12"> <span class="gallery-name"><?php echo ucwords($rec_p['name']);?> <span></div>	
									  <div class="col-lg-12"> 
                                        <?php if(isset($rec_p['address']) && $rec_p['address']!=''){echo $rec_p['address'].",";}?>  <?php if(isset($rec_p['city']) && $rec_p['city']!=''){echo $rec_city['city'].",";}?><?php if(isset($rec_p['state']) && $rec_p['state']!=''){echo $rec_state['state'];}?><?php //if(isset($rec_p['country'])){echo $result['country'];}?>
									  </div>
									  <div class="col-lg-12"> <?php echo     $star->getRating("userChoose size-3"); ?></div>								  
                                </div>							   
								</div> 
							   <?php  } ?>
						
 
							</div>
						 
					</div><!--/col-->
				</div><!--/col-->
			
			</div><!--/row-->

    
					
			</div>
			<!-- end: Content -->
			
			<!-- start: Widgets Area -->
 
<!-- end: Widgets Area -->

<!--<a id="widgets-area-button" class="hidden-sm hidden-xs open"><i class="fa fa-bars"></i></a>-->				
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>
	
<?php  include("resources/templates/script.php"); ?>
 
<script>

function redirectUser(v){
	$("#q").val(v);
	$("#musiciansform").submit();
}


</script>
</body>
</html>