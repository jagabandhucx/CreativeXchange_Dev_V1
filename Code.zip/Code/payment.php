<?php 
include("resources/includes/functions.php");
require("braintree/lib/autoload.php");
require("braintree/lib/Braintree.php");
checkLogin();
$title="Secure Payment ";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];

$getStringvalue=base64_decode($_GET['qs']);
if($getStringvalue!="braintree7222222Integratipon7845552")
{
	header("location:gallery.php");//validate user, if he has come from event details page then proceed , other wise throw him out
}
 
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
			 

$query_state="select * from states";
$sql_state = $dbh->prepare($query_state);
             $sql_state->execute();
             	 


$query_cities="select * from cities";
$sql_cities = $dbh->prepare($query_cities);
             $sql_cities->execute();

	
$query_profession="select * from professions where id='$result[professionid]'";
$sql_profession = $dbh->prepare($query_profession);
 $sql_profession->execute();	
$rec_profession_name= $sql_profession->fetch(PDO::FETCH_ASSOC); 
	//echo $rec_profession_name['name'];	 

$name=$result['name'];	
$eventid=$_SESSION['payeventid'];
$six_digit_random_number = mt_rand(100000, 999999);
$_SESSION['order_id']=$six_digit_random_number;

/**Braintree payment code**/
if(isset($result['braintree_cust_id']) && $result['braintree_cust_id']!=''){
	// Existing cust
 $brainTreeCustomerId=$result['braintree_cust_id'];
 $customer = Braintree_Customer::find($brainTreeCustomerId);
} 
 
/**Braintree payment code end here**/


 // echo "<pre>";
 //print_r($customer);
$clientToken = Braintree_ClientToken::generate();
?>


<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		
<style>
#message{
text-align: center;
font-size: 18px;
background-color: #ebf8a4;
color: #000;
border-radius: 2px;
border:1px solid #a2d246;
}
.form-control{
	border-right: #fff;	
}

 

</style>


</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
			  <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->


			<!-- start: Content -->
			<div id="content" class="col-sm-12"><br><br><br>
			<div class="row">
			<div class="col-lg-3"></div>
				<div class="col-lg-6">
				<form name="checkout" id="checkout" method="post" action="payment-action.php">
				 <input type="hidden" name="typehidden" id="typehidden" value=""/>
				 <input type="hidden" name="c_firstname" id="c_firstname" value="<?php echo $result['name']; ?>"/>
				 <input type="hidden" name="c_email" id="c_email" value="<?php echo $result['email']; ?>"/>
				 <input type="hidden" name="c_phonenumber" id="c_phonenumber" value="<?php echo $result['phone']; ?>"/>		
                 <input type="hidden" name="payment_method_nonce" id="payment_method_nonce" value="" />				 
				      
					  <div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-1"></div>
								<div class="col-lg-10">
								  <div class="controls">
									 <div class="gallery-name"> Total Amount:&nbsp;&nbsp; $<?php echo $_SESSION['tran_amount'];?></div>
								  </div>
								  </div>
								   <div class="col-lg-1"></div>
								</div>
								</div><br>
					  
                     <?php
					 if(isset($brainTreeCustomerId) && $brainTreeCustomerId!=''){
					  foreach($customer->creditCards as $key => $val){
							?>
						<div class="row">
						<div class="col-lg-1"></div>
						<div class="col-lg-10">
						<div class="paymentcard" id="<?php echo $val->token; ?>"><img src="<?php echo $val->imageUrl; ?>" />&nbsp;&nbsp;&nbsp;<!--<span class="cardname"><?php echo $val->cardType;?></span> &nbsp;&nbsp;&nbsp;--><span class="cardnumber"><?php echo $val->maskedNumber; ?> </span>
						
						</div>
						</div>
						<div class="col-lg-1"></div>
						</div>
						<?php }
					 
					 ?>
					 <?php
					    foreach($customer->paypalAccounts as $key => $val){
							?>
						<div class="row">
						<div class="col-lg-1"></div>
						<div class="col-lg-10">
						<div class="paymentcard" id="<?php echo $val->token; ?>"><img src="<?php echo $val->imageUrl; ?>" />&nbsp;&nbsp;&nbsp;<!--<span class="cardname"><?php echo $val->cardType;?></span> &nbsp;&nbsp;&nbsp;--><span class="cardnumber"><?php echo $val->email; ?> </span>
						
						</div>
						</div>
						<div class="col-lg-1"></div>
						</div>
						<?php }
					 
					 ?>
					<div class="row">
						<div class="col-lg-1"></div>
						<div class="col-lg-10">
					<div class="paymentcardnew"><a href="#" class="addnewpayment" onclick="showCarddetails()">Add Payment Method</a></div>
					</div>
					</div>
					</br> 
					<?php }	  ?>
					
				 
					 <div class="row" id="payment_card_rows" <?php if(isset($brainTreeCustomerId) && $brainTreeCustomerId!=''){?> style="display:none;"<?php } ?> >	
							
							<div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-1"></div>
								<div class="col-lg-10">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <div class="form-control focused" id="card_number" name="card_number"   type="text" placeholder="Card number" required ></div>
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-1"></div>
								</div>
								</div>
								</br> 								
							   
							    
								 <div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-1"></div>
								<div class="col-lg-10">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <div class="form-control focused" id="cvv" name="cvv"   type="text" placeholder="CVV" required ></div>
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-1"></div>
								</div>
								</div>
								</br> 								
							    
								
								 <div class="row">		
								<div class="form-group"   >
								  <div class="col-lg-1"></div>
								<div class="col-lg-10">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <div class="form-control focused" id="exp_date" name="exp_date"   type="text" placeholder="Expiration date (MM/YY)"  >
										 </div>
									  <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-1"></div>
								</div>
								</div>
								</br> 

							     
								<div class="row">		
								<div class="form-group" >
								  <div class="col-lg-1"></div>
								<div class="col-lg-10">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										   <input class="btn btn-mini btn-success chpassword BtnContinue" id="BtnContinue22" type="submit"    value="Continue" onclick="getBillingdetails()"/>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-1"></div>
								</div>
								</div>
								</br> 


					 </div>
					 
					  <div class="row" id="payment_billing_rows">		  </div>
				
						<div class="row"  >
						<div class="col-lg-1"></div>
						<div class="col-lg-10">
						<div id="paypal-button"></div>
						</div>
						<div class="col-lg-1"></div>
						</div>
						

				
				
				</form>
 
			  </div>
				<div class="col-lg-3"></div>
		</div>
			
			
			
			
			
			
			
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>	
	
		<?php  include("resources/templates/script.php"); ?>
		<!--<script src="assets/js/braintree-2.32.1.min.js"></script>--->
	 
  <script src="https://js.braintreegateway.com/web/3.26.0/js/client.min.js"></script>
    <script src="https://js.braintreegateway.com/web/3.26.0/js/hosted-fields.min.js"></script>
	 <script src="https://www.paypalobjects.com/api/checkout.js" data-version-4></script>
	 <script src="https://js.braintreegateway.com/web/3.26.0/js/paypal-checkout.min.js"></script>
	 <script type="text/javascript">
 
function showCarddetails(){
	$(".addnewpayment").hide();
  $("#payment_card_rows").slideToggle();
  
}	
 

function getCarddetails(){   
	  
	 var paymentcardrows="data";
	$.post("resources/ajax/payajax.php",{varpaymentcardrows:paymentcardrows},function (data){	   
		 
		 $("#payment_card_rows").html(data); 	 
		
	})
	
}


function getBillingdetails(){   
	  
	 var paymentcardrows="data";
	$.post("resources/ajax/payajax.php",{varpaymentbillingrows:paymentcardrows},function (data){		   
		 
		 $("#payment_card_rows").hide(); 
		$("#payment_billing_rows").html(data); 		 
		
	})
	
}


function makePayment(){
	$(".make_paymentContainer").html('<button class="btn btn-mini btn-success chpassword"  name="make_payment"  type="button"><img src="assets/img/giphy.gif" style="height:50px;" /></button>');
   
	$.post("payment-action.php",$('form#checkout').serialize(),function (data2){		
				
			//alert(data2);	
        window.location=data2;			
			
		})

}

 
      var clientToken = "<?php echo $clientToken;?>";
	  
       var form = document.querySelector('#checkout');
     
	  var submit = document.querySelector('input[type="submit"]');
 
      braintree.client.create({
        authorization: clientToken
      }, function (clientErr, clientInstance) {
        if (clientErr) {
			
          console.error(clientErr);
          return;
        }
        // alert(clientInstance);
        // This example shows Hosted Fields, but you can also use this
        // client instance to create additional components here, such as
        // PayPal or Data Collector.

        braintree.hostedFields.create({
          client: clientInstance,
          styles: {
            'input': {
              'font-size': '14px'
            },
            'input.invalid': {
              'color': 'red'
            },
            'input.valid': {
              'color': 'green'
            }
          },
          fields: {
            number: {
              selector: '#card_number',
              placeholder: '4111 1111 1111 1111'
            },
            cvv: {
              selector: '#cvv',
              placeholder: '123'
            },
            expirationDate: {
              selector: '#exp_date',
              placeholder: '10/2019'
            }
          }
        }, function (hostedFieldsErr, hostedFieldsInstance) {
          if (hostedFieldsErr) {
            console.error(hostedFieldsErr);
            return;
          }

          submit.removeAttribute('disabled');
         
          form.addEventListener('submit', function (event) {
            event.preventDefault();

            hostedFieldsInstance.tokenize(function (tokenizeErr, payload) {
              if (tokenizeErr) {
				   
                console.error(tokenizeErr);
                return;
              }

              // If this was a real integration, this is where you would
              // send the nonce to your server.
			  //alert(payload.nonce);
			  $("#payment_method_nonce").val(payload.nonce);
              //console.log('Got a nonce: ' + payload.nonce);
            });
          }, false);
        });
		
		
		
		  // Create a PayPal Checkout component.
 braintree.paypalCheckout.create({
    client: clientInstance
  }, function (paypalCheckoutErr, paypalCheckoutInstance) {
 
    // Stop if there was a problem creating PayPal Checkout.
    // This could happen if there was a network error or if it's incorrectly
    // configured.
//alert(paypalCheckoutErr);
    if (paypalCheckoutErr) {
      console.error('Error creating PayPal Checkout:', paypalCheckoutErr);
      return;
    }
 
    // Set up PayPal with the checkout.js library
    paypal.Button.render({
      env: 'sandbox', // or 'sandbox','production'

      payment: function () {
        return paypalCheckoutInstance.createPayment({
          flow: 'vault',
          billingAgreementDescription: 'Your agreement description',
          enableShippingAddress: true,
          shippingAddressEditable: false,
          shippingAddressOverride: {
            recipientName: 'Scruff McGruff',
            line1: '1234 Main St.',
            line2: 'Unit 1',
            city: 'Chicago',
            countryCode: 'US',
            postalCode: '60652',
            state: 'IL',
            phone: '123.456.7890'
          }
        });
      },

      onAuthorize: function (data, actions) {
        return paypalCheckoutInstance.tokenizePayment(data)
          .then(function (payload) {
            // Submit `payload.nonce` to your server.
			alert(payload.nonce+"-CX");
			 $("#payment_method_nonce").val(payload.nonce);
			 //make a ajax request 
		$.post("payment-action.php",$('form#checkout').serialize(),function (data2){		
				
		alert(data2);	
        window.location=data2;			
			
		})
			 
			 
			 
			 
          });
      },

      onCancel: function (data) {
        console.log('checkout.js payment cancelled', JSON.stringify(data, 0, 2));
      },

      onError: function (err) {
        console.error('checkout.js error', err);
      }
    }, '#paypal-button').then(function () {
      // The PayPal button will be rendered in an html element with the id
      // `paypal-button`. This function will be called when the PayPal button
      // is set up and ready to be used.
    });

  });
      });

	  
	  
	  

//alert(clientToken);
// Create a client.
// braintree.client.create({
  // authorization: clientToken
// }, function (clientErr, clientInstance) {

  // Stop if there was a problem creating the client.
  // This could happen if there is a network error or if the authorization
  // is invalid.
  // if (clientErr) {
    // console.error('Error creating client:', clientErr);
    // return;
  // }
	// alert("jhiiii");


// });	  
</script>
 
 
 
</body>
</html>
