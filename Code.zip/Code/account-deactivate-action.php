<?php
include("resources/includes/functions.php");
checkLogin();

$id=$_SESSION["user"];

$user_type=$_SESSION["utype"];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //something posted

    if(isset($_POST['btnDeactivate'])) {      
     	// btnDelete		
		 $reasonDeactivate=$_POST['reasonDeactivate'];
		 $other_reason=$_POST['other_reason'];
		echo  $sql="update user_register set deactivate_reason='$reasonDeactivate',deactivate_explain='$other_reason',status='0' where id='$id'";
		 $sql2 = $dbh->query($sql);
		session_destroy();
		 header("location:login.php");
    }  
}
?>