<?php
header("location:profile.php");
?>