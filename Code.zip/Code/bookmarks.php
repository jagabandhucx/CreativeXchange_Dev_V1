<?php 
include("resources/includes/functions.php");
checkLogin();
$title="Follow ";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 	 

$name=$result['name'];		

 /*code for ratings*/			 
if(!isset($_SESSION['user_id'])){
  $_SESSION['user_id'] = $id;
}
			 
require_once __DIR__ . "/config.php";

	/*code for ratings end*/	 
	

?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		 
	
	<style>
.default{
 
height: 28px !important;
border-radius:3px;
}
 
 .col-sm-3{
padding-left:0px;
padding-right:2px;
}

	 .img-thumbnail:hover {
    
     -ms-transform: scale(1.5);
    -moz-transform: scale(1.2);
    -webkit-transform: scale(1.2);
    -o-transform: scale(1.2);
    transform: scale(1.5);
	border-radius:2px;
	z-index:99;
	position:relative;
	 
 
}


 
</style>	
	<link href="src/css/style-upcomingevent.css" rel="stylesheet" type="text/css" />	
		 
</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>		
	<!-- start: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
		 <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!--<a id="main-menu-toggle" class="hidden-xs open"><i class="fa fa-bars"></i></a>-->
			<!-- end: Main Menu -->


			
			
			<!-- start: Content -->
			<form name="bookmark" id="bookmark" method="post" action="">
                         <input type="hidden" name="q" id="q" value="" />

                       </form>	
			<div id="content" class="col-sm-12">
			
				 
			   
		
			<div class="row sortable">
				<div class="col-lg-12" style="z-index:0;">
					<div class="box">
						
					 
							
							<div class="row">
							
							 <?php
							  $sql="select * from bookmarks where created_by='$id'";
							   $sql_b= $dbh->prepare($sql);
							   $sql_b->execute();
							   if($sql_b->rowCount()>0){
							   while($rec_b = $sql_b->fetch(PDO::FETCH_ASSOC))
							   {
							   $bid=$rec_b['bookmark_id'];  
							   $query_p="select id,name,profile,professionid from user_register where  id='$bid'";
							   $sql_p = $dbh->prepare($query_p);
							   $sql_p->execute();
							   $rec_p = $sql_p->fetch(PDO::FETCH_ASSOC);
							   
								   $uid=$rec_p['id'];
								   if($rec_p['profile']!=''){
										$img=$rec_p['profile'];
										}
										else{$img='a2.png';}
										$star->id = $uid;
							   ?>
							
								<div style="margin-bottom:30px;" class="col-sm-3 col-xs-6 clsoverlay1">
									<a href="#" onclick="redirectUser(<?php echo $uid;?>,<?php echo $rec_p['professionid'];?>)"><img class="img-thumbnail" src="images/profile/
									<?php echo $img; ?>" alt="<?php echo $rec_p['name']; ?>" title="<?php echo $rec_p['name']; ?>" style="height:180px;width: 253px;"></a>
									<span class="innerheading"> <?php echo     $star->getRating("size-4",'html','user'); ?>				
									
									</span>
									 <div class="overlay">
								<a href="#" onclick="redirectUser(<?php echo $uid;?>,<?php echo $rec_p['professionid'];?>)" class="text" style="text-decoration:none;">Show Profile</a>
	  
								</div>					
								</div> 
					 <?php  }
						} else{?>
							<div style="text-align:center;"><h1> No bookmark yet</h1></div>
						<?php }

					 ?>
						
 
							</div>
						 
					</div><!--/col-->
				</div><!--/col-->
			
			</div><!--/row-->

    
					
			</div>
			<!-- end: Content -->
			
			<!-- start: Widgets Area -->
 
<!-- end: Widgets Area -->

<!--<a id="widgets-area-button" class="hidden-sm hidden-xs open"><i class="fa fa-bars"></i></a>-->				
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>
	
<?php  include("resources/templates/script.php"); ?>

<script>
function redirectUser(v,type){
	//alert(type);
	$("#q").val(v);	
	if(type==1){
	 $("#bookmark").attr("action", "show-photographer-gallery.php");
	}else if(type==2){
	 $("#bookmark").attr("action", "musician-gallery.php");
	}
	 $("#bookmark").submit();
	
}

</script>


</body>
</html>