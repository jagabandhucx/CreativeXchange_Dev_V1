<?php 
include("resources/includes/functions.php");
$title="Create Password";
if(isset($_GET['q2']) && $_GET['q2']!=''){
 $uid=$_GET['q2'];	
 $useriddd=base64_decode($uid);
  $query="select id,password from user_register where id='$useriddd'";
	 $sql = $dbh->prepare($query);
	   $sql->execute();
	   //echo $sql->rowCount();
	   if($sql->rowCount()>0){
		   $rec_user = $sql->fetch(PDO::FETCH_ASSOC); 
		   if($rec_user['password']!=''){
			   header("location:login.php");
		   }
	   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		


<style>

.navbar-inner{
min-height:43px;
// background-image: url("images/header-login.png");
background-color: #4267b2;
background-size:60px 60px!important;
background-position: center; 
}
.navbar{
min-height:43px;	
}
.navbar-inner .bit{
    position: absolute;
    height: 94px;
    width: 94px;
    left: 48%;
    top: 0px;
    margin-left: -47px;
	z-index:9999;
	padding:26px;
	font-size:28px;
	color:#ffffff;
	font-weight:600;
    letter-spacing: 5px;
}
footer{
margin: 0;	
}
#content{
min-height: 100px !important;	
}

</style>
</head>

<body>
		<!-- start: Header -->
  <?php//include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	<div class="navbar loginnav">
		<div class="navbar-inner">
			<div class="container">
				 
						<div class="bit bit--logo text--center" data-reactid="6"><div class="bit__content" data-reactid="7"><img src="images/logo2.png" style="height:100px;" /> </div></div>		
		
				
			</div>
		</div>
	</div>
	
	
	
	
	
	
	
	
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
			  <?php  //include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->


			<!-- start: Content -->
			<div id="content" class="col-lg-12 login-content">
			
		 
			 
		    	<form name="passwordform" id="passwordform" method="post">
			 
		    <input type="hidden" name="uid" id="uid" value="<?php echo $uid;?>" />
			<div class="row" >		
				<div class="col-lg-12">
					<div class="box">
				 <div class="row">		
								<div class="form-group" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6" >
								 <div class="controls">
								   <div  class="login-heading">  Create Password   </div>
								</div>								   
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
		
					
					          <div class="row" id="showmessage"  style="display:none;">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										  <div class="row" id="message" style="color: red;font-weight: 600;font-size: 17px;">	</div>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
					
	                   
					   
					   
					    
					 
					 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused input-border-right-white" id="password" name="password"   type="password" placeholder="Password" onblur="CheckPassword(this.value)" required >
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
							
							
							 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused input-border-right-white" id="confirm_password" name="confirm_password"   type="password" placeholder="Confirm Password" required>
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
						 
								 
					 
								
								 
								<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12 submitBtnrow">
										
										   <button class="btn btn-mini btn-success chpassword" type="button"  onclick="createPassword()">Create Password</button>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								 
								
								 
								 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										  
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								 
								 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										  
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								
								
								 
								
								 
								
								 
						 
					</div>
				</div><!--/col-->
			
			</div><!--/row-->

			</form>
			
			

		  
			
			
			
			    <div class="row ">	</div>
								 
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
		<footer class="loginBottomsec">
		
		<div class="row">
			
			<div class="col-sm-5">
				 
			</div><!--/.col-->
			
			<div class="col-sm-7 text-right">
				 
			</div><!--/.col-->	
			
		</div><!--/.row-->
		
	</footer>
		<footer>
		
		<div class="row">
			
			<div class="col-sm-5">
				&copy; 2017 Creative Xchange.
			</div><!--/.col-->
			
			<div class="col-sm-7 text-right">
				 <a href="">Privacy Policy | Terms and Conditions</a>
			</div><!--/.col-->	
			
		</div><!--/.row-->
		
	</footer>
	
	
	
 	<?php  //include("resources/templates/footer.php"); ?>	
	
		<?php  include("resources/templates/script.php"); ?>
<script>

function CheckPassword(password)   
{       if(password!=''){
		var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;  
		if(password.match(decimal))   
		{   
		//alert('Correct, try another...')  
		return true;  
		}  
		else  
		{   
		alert('password should 8 to 15 characters which contain at least one lowercase letter, uppercase letter, numeric digit and one special character!') 
		$("#password").val('');
		document.getElementById("password").focus();		
		return false;  
		}  
	}
}   


		function createPassword(){
		var cpassword=$("#confirm_password").val();	
		var password=$("#password").val();
		var uid=$("#uid").val();
		
		if(password==''){
		alert("Enter password. ");	
		document.getElementById("password").focus();
		return false;
		}
		// if(!CheckPassword(password)){
			// return false;
		// }
		
		if(cpassword==''){
		alert("Enter confirm password.");	
		document.getElementById("confirm_password").focus();
		return false;
		}
		if(password!=cpassword){
			alert("Password and confirm password should match.");	
		document.getElementById("confirm_password").focus();
		return false;
		}
		
		if(uid==''){
				$("#message").html("Error occured.");
				$(".submitBtnrow").html('');
				return false;
		}
		
		$(".submitBtnrow").html(' <button class="btn btn-mini  loginBtn" type="button"  style="padding-top:0;"><img src="assets/img/giphy.gif" style="height:50px;" /></button>');
			
			//alert(email);
			$.post("resources/ajax/register-ajax.php",{varCreatepassword:password,varUid:uid},function (data){
				alert(data);
				
				if(data==2){
					$("#message").html("User did not find.");
					$("#showmessage").show();
						$(".submitBtnrow").html('<button class="btn btn-mini btn-success chpassword" type="button"  onclick="createPassword()">Create Password</button>');
				}else if(data==1){
					
					window.location.href="login.php";
				
				}
				
				
			});
		}

</script>


</body>
</html>
