<?php
include("resources/includes/functions.php");
checkLogin();
$title='Events ';
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
$name=$result['name'];



if($user_type==1){
$sql_orders="select e.*,u.name,u.profile,u.professionid from events e left join user_register u on e.created_by=u.id  where e.assigned_to='$id'";

}else if($user_type==2){
$sql_orders="select e.*,u.name,u.profile,u.professionid from events e left join user_register u on e.created_by=u.id  where e.created_by='$id'";	
}
if(isset($_GET['eventnamedrp']) && $_GET['eventnamedrp']!=''){
	$event_type=$_GET['eventnamedrp'];
	$sql_orders.=" and e.id=$event_type ";
}

$sql_orders.=" order by e.date_from desc";

$res_orders=$dbh->prepare($sql_orders);
$res_orders->execute();


// below code for search dropdown

if($user_type==1){
$sql_orders2="select e.*,u.name,u.profile,u.professionid from events e left join user_register u on e.created_by=u.id  where e.assigned_to='$id' order by e.date_from desc";

}else if($user_type==2){
$sql_orders2="select e.*,u.name,u.profile,u.professionid from events e left join user_register u on e.created_by=u.id  where e.created_by='$id' order by e.date_from desc";	
}


$res_orders2=$dbh->prepare($sql_orders2);
$res_orders2->execute();

?> 
<!DOCTYPE html>
<html lang="en">
<head>
	  <?php  include("resources/templates/head.php"); ?>	
   <link rel="stylesheet" href="assets/js/datatables/datatables.css" type="text/css"/>
	<!-- end: Favicon and Touch Icons -->
	
	<style>
table tbody tr td a:hover{
text-decoration:none !important;
}

nav-tabs a{
width : 75%;
}

h2.title a{
color:#484848;
}
// .event-list .info:hover{
 // background-color:#f5f5f5;
// background-color:#FFFAFA;
// }
.eventsli{
	width:48% !important;
 margin-right:10px !important;
}
.eventbtn{
	height:26px;
	 background-color:#11939A;
	 border:2px solid #11939A;
	 color:#ffffff;
	 border-radius:1px;
}


.eventbtn:hover{
	 background-color:#0c6c71 !important;	
	  border:2px solid #0c6c71;
}

#watermark{
    // position:absolute;
    z-index:0;
    
    display:block;
    min-height:50%; 
    min-width:50%;
    color:yellow;
	position: absolute;
   top: 50%;
left: -107px;
}

#watermark #watermark-text
{    opacity: 0.5;
    color:#11939A;
    font-size:22px;
    transform:rotate(300deg);
    -webkit-transform:rotate(300deg);
	font-weight: 600;
	border: 1px solid;
    padding-left: 10px;
	border-radius: 2px;
}
</style>	
		
		
</head>

<body>
		<!-- start: Header -->
	  <?php  include("resources/templates/header.php"); ?>	
	<!-- start: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
		 
 <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->

			
			<!-- start: Content -->
			<div id="content" class="col-sm-12">
			
			
			<div class="row">		
				<div class="col-lg-12">
					<div class="box">
						     <div class="container">
							
									    <div class="row" id="searchdropdown" >
										
										     <div class="col-lg-6">
											     
													 
													 <div class="form-group">
														<!--<label class="control-label" for="selectError20">Group Select</label>-->
														<div class="controls">
														  <form class="form-horizontal" name="eventSearchform" id="eventSearchform" method="get" style="margin-right:42px;">
														    <!--<button name="nakk" id="searchBtn" onclick="showSearcharea()"> <i class="fa fa-search"></i></button> &nbsp; &nbsp; -->
															<select class="form-control" data-placeholder="Search using event name" id="eventnamedrp" name="eventnamedrp" 
data-rel="chosen"  onchange="submitSearchform()" style="display:none;">
																 <option value=""> &nbsp; Search using event name</option>
																<optgroup label="">
																<?php 
																  while($rec_orders2 = $res_orders2->fetch(PDO::FETCH_ASSOC))
																	{								  
																?>
		<option value="<?php echo $rec_orders2['id']; ?>"   <?php if(isset($_GET['eventnamedrp']) && $_GET['eventnamedrp']!='' && $_GET['eventnamedrp']==$rec_orders2['id']){ ?>selected  <?php } ?>>									
														<?php echo ucfirst($rec_orders2['event_type']);?>&nbsp;&nbsp; (<?php   echo date("d-m-Y",strtotime($rec_orders2['date_from'])); ?>)	</option>
																
															  <?php } ?>
																
															
																
																 
																</optgroup>
															
																 
															
															</select>
															</form>
														</div>
													</div> 
												 
												 </div>
												 </div> 
													 
							 
							 
							 
		<div class="row">
			<div class="col-lg-12">
				<ul class="event-list col-lg-12">
				
				 <?php			   
				                
								 if($res_orders->rowCount()>0){
								
							   while($rec_orders = $res_orders->fetch(PDO::FETCH_ASSOC))
							   {
								   $date_noti=$rec_orders['date_from'];
								   $elapsed_notification_time=time_elapsed_string($date_noti);
								   $eventid=$rec_orders['id'];
								   $monthNum  = date("m",strtotime($date_noti));
									$dateObj   = DateTime::createFromFormat('!m', $monthNum);
									$monthName = $dateObj->format('M'); 
									
									$query_time="select * from events_time where event_id='$rec_orders[id]'";
									$query_time = $dbh->prepare($query_time);
									 $query_time->execute();
									 $result_time = $query_time->fetch(PDO::FETCH_ASSOC);
									 
									 if($rec_orders['status']==0){
										 $eventstatus='pending-event';
									 }else if($rec_orders['status']==1){
										 $eventstatus='approved-event';
									 }else if($rec_orders['status']==2){
										 $eventstatus='cancel-event';
									 }
									  $event_status=trim($rec_orders['status']);
									  $eventtype=$rec_orders['event_type'];
									 
									 if(strlen($eventtype)>45){
										 $eventtype= substr($eventtype,0,35);
										 $eventtype.=" ..";
										 }
									 
									  
												 
							   ?>
							   
					<li  id="events<?php echo $eventid;?>" class="col-sm-12 col-lg-6 col-md-6  col-xs-12 eventsli" >
						<time datetime="2014-07-20" class="<?php echo $eventstatus;?>">
						
							<span class="day"><?php echo date("d",strtotime($date_noti));?></span>
							<span class="month"><?php echo $monthName;?></span>
							<span class="year">2014</span>
							<span class="time">ALL DAY</span>
							 <?php if(isset($rec_orders['payment_status']) && $rec_orders['payment_status']==1){ ?>
							<span id="watermark">
								<label id="watermark-text"> Paid &nbsp;&nbsp; </label>
							</span>
							<?php } ?>
						</time>
						<!--<img alt="" src="assets/img/weddingsign.jpg" />-->
						<div class="info">
							
							<h2 class="title   <?php if(isset($_GET['q']) && $_GET['q']!='' && $_GET['q']==$eventid){	?> blink_me	<?php  }?> ">
							<a href="show-event-details.php?qs=<?php echo base64_encode($eventid);?>">
							<?php echo $eventtype;?>  
							</a>
							</h2>
							<div>Creative type Public</div> 
							<div ><i class="fa fa-map-marker"></i> &nbsp;<?php echo ucwords($rec_orders['location']);?></div>    
                                
						     <div><i class="fa fa-user"></i> <?php echo ucwords($rec_orders['name']); 
							 if($rec_orders['assigned_to']==1){echo " (Photographer)";} else if($rec_orders['assigned_to']==2){echo " (Musician)";}

							 ?></div> 
							 
							 
							 <div class="event-statusdiv">  
							 <?php 
							 if($user_type==1){
							if($event_status==1){?>
								<span style="color: #78cd51;">Approved</span>
								
						<?php	} 					
							else if($event_status==0){?>
								
								<!--<input type="button" name="eventApprovebtn" onclick="eventsApprove(<?php echo $eventid;?>)"  id="eventApprovebtn" class="eventbtn" value="Approve"/>
								<input type="button" name="declinebtn" onclick="eventsDeclined(<?php echo $eventid;?>)" id="declinebtn" class="eventbtn" value="Decline"/>-->
								<!--<span onclick="eventsApprove(<?php echo $eventid;?>)"><i class="fa fa-check" style="color:#78cd51;" title="Approve"></i></span> &nbsp; &nbsp;&nbsp;  <span onclick="eventsDeclined(<?php echo $eventid;?>)"><i class="fa fa-times" style="color:#ff2121;" title="Decline"></i></span>--->
								
							<?php }else if($event_status==2){?>
								 <!--<span onclick="eventsApprove(<?php echo $eventid;?>)"><i class="fa fa-check" style="color:#78cd51;"></i></span> --> &nbsp;&nbsp;<span style="color: #ff5454;">Declined</span> 
								
							<?php }
							 }else  if($user_type==2){
								  if($event_status==1){ echo '<span style="color: #78cd51;">Approved</span>';  }else if($event_status==2){echo '<span style="color: #ff5454;">Declined</span> '; }
								 ?>
								 
								 
							<?php  }
							?>
								
							 </div>
							 
							 
						</div>
						<div class="social">
							<ul>
								<li class="facebook" style="width:33%;"><a href="<?php echo $rec_orders['fburl']?>" target="_blank"><span class="fa fa-facebook"></span></a></li>
								<li class="twitter" style="width:34%;"><a href="<?php echo $rec_orders['twitterurl']?>" target="_blank"><span class="fa fa-twitter"></span></a></li>
								<li class="google-plus" style="width:33%;"><a href="<?php echo $rec_orders['googleurl']?>" target="_blank"><span class="fa fa-google-plus"></span></a></li>
							</ul>
						</div>
					</li>
						  
			 <?php	} 
				}	 else { ?>
				 <div style="text-align:center;"> <h1>No Event </h1></div>
				 
			<?php  }	 ?>
				 

					 
				</ul>
			</div>
		</div>
	</div>

						
						
						 
					</div>
				</div><!--/col-->
			
			</div><!--/row-->

			
			
			
			
			
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>
	
	<!-- start: JavaScript-->
	<?php  include("resources/templates/script.php"); ?>
 	<script src="assets/js/pages/table.js"></script>
	
<script type="text/javascript">
		//code for search box
 

 

 
	</script>
	
	
	<script>
	function eventsApprove(val){
		 
		$.post("resources/ajax/event-action.php",{vareventapprpoveid:val},function (data){
			 
			 $("#events"+val).html(data);
			 
		})
		
	}	
	
		function eventsDeclined(val){
		 
		$.post("resources/ajax/event-action.php",{vareventdeclineid:val},function (data){
			 
			 $("#events"+val).html(data);
			 
		})
		
	}


	function submitSearchform(){
		 
		$("#eventSearchform").submit();	
		
	}
	
function showSearcharea(){
	 
	$("#searchdropdown").show();
}
	
	</script>
	
	<script language="javascript" type="text/javascript">
       $(document).ready(function () {
           
       });
    </script>
 
</body>
</html>