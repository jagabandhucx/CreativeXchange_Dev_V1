<?php
include("resources/includes/functions.php");
checkLogin();
$title='My Gallery';
$id=$_SESSION["user"];
$loginuserid=$id;
$user_type=$_SESSION['utype'];
 
if(isset($_POST['q']) && $_POST['q']!=''){
$musicianid=$_POST['q'];
}else{
$musicianid=$id;	
}
 
//echo "--".$id."--".$loginuserid;
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
$name=$result['name'];


$query_musician="select * from user_register where id='$musicianid'";
$sql_musician = $dbh->prepare($query_musician);
             $sql_musician->execute();
             $result_musician = $sql_musician->fetch(PDO::FETCH_ASSOC); 
$name_musician=$result_musician['name'];
//echo $_FILES['upload-file']['name'];
/*code for ratings*/			 
if(!isset($_SESSION['user_id'])){
  $_SESSION['user_id'] = $id;
}
	
	
require_once __DIR__ . "/config.php";
$star->id = $musicianid;
/*code for ratings end*/
?> 
<!DOCTYPE html>
<html lang="en">
<head>
	
<?php  include("resources/templates/head.php"); ?>	
	
	<style>
.default{
 
height: 28px !important;
border-radius:3px;
}
 
 .col-sm-3{
padding-left:0px;
padding-right:2px;
}

 

#profiledtl{
height: 350px;
margin-bottom: 24px;
margin-left: 5px;
max-width: 99.1%;
}
.musicsrow a{
color:#4267b2;
font-weight: 600;
}

.playpause {
    background-image:url(assets/img/video.png);
    background-repeat:no-repeat;
    width:50%;
    height:50%;
    position:absolute;
    left:0%;
    right:0%;
    top:0%;
    bottom:0%;
    margin:auto;
    background-size:contain;
    background-position: center;
}
video0:hover{
background-image:url(assets/img/video.png);
    background-repeat:no-repeat;
    width:50%;
    height:50%;
    position:absolute;
    left:0%;
    right:0%;
    top:0%;
    bottom:0%;
    margin:auto;
    background-size:contain;
    background-position: center;
}


.img-thumbnail {
   
    -webkit-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
    display: inline-block;
    
}

.profileBtnDiv ul li {
float:right;
margin-right:20px;
list-style-type:none;
margin-top: 5px;
font-weight:600;
border-right:1px solid #d3d6db;
padding-right: 9px;

}	
.profileBtnDiv ul li a{
text-decoration:none;
}	
		
		
/* The Modal (background) */
.modal {
display: none; /* Hidden by default */
position: fixed; /* Stay in place */
z-index: 1; /* Sit on top */
padding-top: 47px; /* Location of the box */
left: 0;
top: 0;
width: 100%; /* Full width */
height: 100%; /* Full height */
overflow: auto; /* Enable scroll if needed */
background-color: rgb(0,0,0); /* Fallback color */
background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
background-color: #fefefe;
margin: auto;
padding: 20px;
border: 1px solid #888;
width: 50%;
}


		
.musicsrow .col-sm-3 {
    max-height: 224px;
}	

.closeBtn{
	position: absolute;
right: 10px;
top: 5px;
}	

input[type="file"] {
display: inline-block;
opacity: 0;
position: absolute;
z-index: 99;
margin-top: 10px;
cursor: pointer;
}
.custom-file-upload {
position: relative;
display: inline-block;
cursor: pointer;
margin-bottom: 0px;
font-weight: 400;
margin: 10px;
border: 1px solid;
padding: 2px 5px;
border-radius: 3px;
cursor: pointer;
}
</style>	
		
		 
</head>

<body>
<!--<div class="se-pre-con"></div>-->
		<!-- start: Header -->
	<?php  include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
 <?php  include("resources/templates/left-menu.php"); ?>
			
		<!-- The Modal -->
						<div id="myModal" class="modal">

						  <!-- Modal content -->
						  <div class="modal-content">   
						  <i class="fa fa-times  close2"></i>
                          						  
                           
							   								
							<div class="row">	
                             <div class="col-sm-12" >							
							<div class="form-group">								 
								<div class="controls">
									<div id="dropzone">
										<form action="upload-video.php" class="dropzone">
											<div class="fallback">
												<input name="file" type="file" multiple="" />
											</div>
										</form>
									</div>
								</div>
							 </div>	
							 </div>	
							  </div>	
							 
							<!-- <div class="form-group">								 
								<div class="controls">
								 <div class="col-sm-11">
								 <input type="text" class="form-control" id="youtubeurlTxt" name="youtubeurlTxt" value=""     placeholder="Enter Youtube or Vimeo URL"/>
								 <button class="btn btn-mini btn-success" type="button" onclick="UpdateYoutubeUrl()">Save</button>
								</div>
								 
								</div>
							 </div>	-->
								
							<div class="row youtubeuploaddiv" style="">	
                               <div id="video-message" style="margin:10px 0;font-size:15px; font-weight:600;padding-left:13px;">  </div>							
							    <div class="col-sm-10"  >
							       <input type="text" class="form-control" id="youtubeurlTxt" name="youtubeurlTxt" value=""     placeholder="Enter Youtube or Vimeo URL"   >
								   </div>
								 
								<div class="col-sm-2"><button class="btn btn-mini btn-success" type="button" onclick="UpdateYoutubeUrl()" style="width: 100%;">Save</button></div>
						      </div>   

								
															
						  </div>

						</div>	
			
	
<div id="editVideoModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
     <a href="#" class="closeBtn" >×</a>
     
	  						 
		 	    <div class="row sortable">
				<div class="col-lg-12 editVideodata"  >
				<img src="images/ajax-loader.gif"  />
					 
				  </div>
				  </div>
				  
		</div>
	</div>	
	
			
		<form action="create-event.php" name="events_form" id="events_form" method="post">
<input type="hidden" name="qid" id="qid" value="" />
<input type="hidden" name="profession_id" id="profession_id" value="2" />
</form>
	
	<input type="hidden" name="artistid" id="artistid" value="<?php echo $musicianid;?>" />	
    <input type="hidden" name="ratingstype" id="ratingstype" value="user" />
				
			<!--<a id="main-menu-toggle" class="hidden-xs open"><i class="fa fa-bars"></i></a>-->
			<!-- end: Main Menu -->

			 <?php if(isset($result['cover_photo']) && $result['cover_photo']!=''){ 
			    $background_image=$result['cover_photo'];
				$txt="Update Cover Photo";
			   }else{
				  $background_image="background.jpg"; 
					$txt="Add Cover Photo";				  
			   }
			   
			   ?> 
			<!-- start: Content -->
			<div id="content" class="col-sm-12">
	                 <div class="row" style="background-image: url('images/cover-photo/<?php echo $background_image;?>');">
						<div  class="col-sm-12">
						
						 <div class="cover-photo"> 
					    <form name="coverphotoform" id="coverphotoform" method="post" action="cover-photo-action.php" enctype="multipart/form-data">
						<input type="hidden" name="source_page" id="source_page"  value="photographer-gallery.php"/>
						  <input type="file" id="upload" name="fileToUpload" onchange="FormSubmit()">
						   <label for="file-upload" class="custom-file-upload"><i class="fa fa-camera"></i>  <?php echo $txt;?></label>	
						    </form>
					     </div>	
						  

						 <div style="height:200px;"></div>
						 <div style="background-color:#fff; height:36px;border:1px solid #d3d6db;"> 
						 <div  style="float:right;" class="profileBtnDiv">
						 <ul>
						  <li id="bookmarkli">
						 <?php
						 $query_bookmarks="select * from bookmarks where created_by ='$id' and bookmark_id='$musicianid'";
						 $res_bookmarks = $dbh->prepare($query_bookmarks);
						 $res_bookmarks->execute();
						if($res_bookmarks->rowCount()>0){?>
						
						
						<a href="#" onclick="removebookmarkArtist(<?php echo $musicianid;?>)" title="Unfollow" class="following"> Following</i> </a>
						<?php } else{
						 ?>
						 <a href="#" onclick="bookmarkArtist(<?php echo $musicianid;?>)" title="Follow" class="follow"> Follow</a>
						 
						<?php }?>
						 </li>
						 
						 
						<!--<?php if($user_type=='2'){ ?> <li> <a  href="#" onclick="createEvents(<?php echo $musicianid;?>)" >Book</a> </li><?php } ?>-->
						<li> <a   href="profile.php?qa=<?php echo base64_encode($musicianid);?>" >About</a> </li>
						 <?php if($loginuserid==$musicianid){ ?>
						 <li> <a   href="#" id="myBtn">Manage Gallery</a> </li> 
						  
						 <?php } ?>
						  <li>  <?php echo     $star->getRating("userChoose size-4",'html','user'); ?> </li>
						    
						  
						 
						 </ul>
						 <?php if($musicianid!=$id){ ?>  <a   href="#" onclick="createEvents(<?php echo $qid;?>)" > <button class="btn btn-mini btn-success chpassword booknowBtn"   type="button">Book Now</button>  </a><?php } ?>
						
						 </div>
						 </div>
						   <span style="left: 4%; position: absolute;top: 62px;border:1px solid #d3d6db;border-radius:3px;"> 
						   <!---<img src="assets/img/gallery/medium_facebook-profile.jpg"  style="border:3px solid #fff;" />--->
						   <?php if(isset($result_musician['profile']) && $result_musician['profile']!=''){?>
										
										 <img src="images/profile-thumbnail/<?php echo $result_musician['profile'];?>" class="dker profile-pic2" style="border:3px solid #fff; height:150px; width:150px;">
										
										<?php } else {?>
                                       <img src="images/profile-thumbnail/default-thumb.png" style="border:3px solid #fff;">
										<?php } ?>
						  
						   
						   </span>
						   
						    <span   class="profileName" style="left:18%;width:50%;top:95px;"> 
							 <?php echo ucwords($name_musician); ?>
 							
							</span>
							<?php 
							if($result_musician['venues']!=''){
							?>
							<span   title="Venues"  style="left:18%;width:50%;top:137px; position: absolute;color:#fff;"> 
							 <?php echo ucwords($result_musician['venues']); ?>
 							
							</span>
							<?php } ?>
							
							
							<?php 
					 
					  if(isset($result_musician['city']) && $result_musician['city']!=''){
						  
						  $city=$result_musician['city'];
						  $query_city="select city from cities where id='$city'";
						 $res_city = $dbh->prepare($query_city);
						 $res_city->execute();	
						 $rec_city= $res_city->fetch(PDO::FETCH_ASSOC); 
						 
						 if(isset($result_musician['state']) && $result_musician['state']!=''){
							 $state=$result_musician['state'];
							 $query_state="select state from states where state_code='$state'";
						 $res_state = $dbh->prepare($query_state);
						 $res_state->execute();	
						 $rec_state= $res_state->fetch(PDO::FETCH_ASSOC); 
						 }
					  }

								if(isset($result_musician['country']) && $result_musician['country']!=''){
  
									  $countryid=$result_musician['country'];
									  $query_country="select nicename from country where id='$countryid'";
									 $res_country = $dbh->prepare($query_country);
									 $res_country->execute();	
									 $rec_country= $res_country->fetch(PDO::FETCH_ASSOC); 
									 
								   }															
																 
					  ?>
							<span class="profileAddress" style="left:18%;width:50%;top:162px; ">
							 <i class="fa fa-map-marker"></i>
					  <?php if(isset($result_musician['address']) && $result_musician['address']!=''){echo $result_musician['address'].",";}?>  <?php if(isset($result_musician['city']) && $result_musician['city']!=''){echo $rec_city['city'].",";}?><?php if(isset($result_musician['state']) && $result_musician['state']!=''){echo $rec_state['state'].",";}?><?php if(isset($result_musician['country'])){echo $rec_country['nicename'];}?>
							</span>
						 
						 
						 
						</div>
						</div>
						
		
											<div class="row sortable">
												<div class="col-lg-12" >
													<div class="box">
						
													<!---<div class="box-content" style="background-color:#fff;">-->
													    <div class="row musicsrow">
																
																<?php
																   $query_p="select * from store where  pid='2' and user_id='$musicianid' order by id desc";
																   $sql_p = $dbh->prepare($query_p);
																   $sql_p->execute();
																   while($rec_p = $sql_p->fetch(PDO::FETCH_ASSOC))
																   {
																	   $pi_id=$rec_p['id'];
																	   $datetime=$rec_p['date'];	
																	   $elapsedtime=time_elapsed_string($datetime);
																	   
																	   $sqlgetcomments="select count(*) from messages where tbl_name='store' and tbl_id='$pi_id'";
																	   $rescommentscount=$dbh->query($sqlgetcomments);
																	    $total_video_comment=$rescommentscount->fetchColumn();
																		$star->id = $pi_id;//ratings
																   ?>
																	 
															
															
																			<div   class="col-sm-3 col-xs-6 " style="margin-bottom:35px;">
																			
																			   
																			   <a href="#"   onclick="countView(<?php echo $pi_id;?>)">
																			   <?php if(isset($rec_p['thumbnail']) && $rec_p['thumbnail']!=''){ ?>
																			   <img width="295" height="190" src="assets/img/video-thumbnail/<?php echo $rec_p['thumbnail'];?>" />
																			   <?php }else{ ?>
																			    <img width="295" height="190" src="assets/img/video-thumbnail/thumbnail-no.jpg" />
																			   <?php } ?>
																			   </a>
																			   
																				
																				<div class="titlebox" >
																			     <a href="#" onclick="countView(<?php echo $pi_id;?>)" id="videotitle<?php echo $pi_id;?>" > 
																						<?php
																							if($rec_p['title']!=''){
																						      echo substr($rec_p['title'],0,50)."..";
																							}
																						
																						?>  </a></br>
																						<div style="float:left;"> 
																						  <?php echo     $star->getRating("size-4",'html','video'); ?></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																						<span><i class="fa fa-comment-o"></i> <?php echo $total_video_comment;?></span></br>
																						
																				<span class="video-view"><?php echo $rec_p['user_view']; ?> views . <?php echo $elapsedtime; ?></span>
																				
																				  
																				<?php 
																				
																				if($rec_p['user_id']==$id){ ?> 
																				&nbsp;&nbsp;&nbsp;<span class="editVideo" editvideoid="<?php echo $pi_id;?>"><i class="fa fa-edit"style="cursor:pointer;"></i></span> &nbsp;&nbsp;&nbsp;
																				  <span class="close" videoid="<?php echo $pi_id;?>" style="float:none;"> <i class="fa fa-trash-o" style="font-size: 19px; color:#000;"></i></span>&nbsp;&nbsp;&nbsp;
																				
																				<?php } ?> 
																				
																				</div>
																				 
																		
																		  </div> 
																		  
																   <?php } ?>									  
															</div>
						 
													<!--</div>/col-->
											    </div><!--/col-->
										
										    </div><!--/row-->
										</div>
    
					
			</div>
		 
			<!-- end: Content -->
			
 

<!--<a id="widgets-area-button" class="hidden-sm hidden-xs open"><i class="fa fa-bars"></i></a>-->				
				</div><!--/row-->
		 
		 
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
  <?php  include("resources/templates/footer.php"); ?>	
  
  <?php  include("resources/templates/script.php"); ?>	
	
	 <script src="assets/js/dropzonevideogallery.min.js"></script>
<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");
 
// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close2")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}




// Get the video edit popup
$(".editVideo").click(function(){
    
	 var editVideoModal = document.getElementById('editVideoModal');
	 editVideoModal.style.display = "block";
	 
	 var videoid =$(this).attr('editvideoid');
	 $.post("resources/ajax/gallery-data.php",{vareditvideoid:videoid},function(data){
		// alert(data);
		 $("#videocategory select").trigger("liszt:updated"); 
		 $(".editVideodata").html(data);
		
	 })
	 
});

$(".closeBtn").click(function(){
	editVideoModal.style.display = "none";
});


/*$("#btnSubmitVideoeditdata").click(function(){
	
})	*/

function saveVideodata(){
	 
		var videoid=$("#videoEditid").val();
		var videocategory=$("#videocategory").val();
		var videodesc=$("#videodesc").val();
		var videotitle=$("#videotitle").val();	
		
        $.post("resources/ajax/gallery-data.php",{vareditvideoidupdate:videoid,varvideocategory:videocategory,varvideodesc:videodesc,varvideotitle:videotitle},function(data){
			//alert(data);
			$("#videotitle"+videoid).html(videotitle);
			$("#editVideoModal").hide();
			//window.location="musician-gallery.php";
		  
	 })
	 
	
}

	// // Wait for window load
	// $(window).load(function() {
		// // Animate loader off screen
		// $(".se-pre-con").fadeOut("slow");;
	// });

	
	function FormSubmit(){
		$("#coverphotoform").submit();		
	}
	


</script>
  <script>
  
 

  
  	function  follow(){
		     $(".following").text("Unfollow");
		}
		
		function  unfollow(){
		     $(".following").text("Following");
		}
  
  	$(function(){
		  var prev;    

		  $('.following').hover(function(){
		  prev = $(this).text();
			  $(this).text("Unfollow");
		  }, function(){
			  $(this).text(prev)
		  });
		})
		
		
  function countView(vid){
	  
	 $.post("resources/ajax/artist-ajax.php",{varvideoid:vid},function (data){
	  //alert(data);
	  window.location.href="show-videos.php?q="+data;
	 } )
	  
  }
  
  
  	function createEvents(val){
		
	$("#qid").val(val);	
	$('form#events_form').submit();
	
	}
	
	
	function  bookmarkArtist(v){
		 
		$.post("resources/ajax/event-action.php",{varbookmarkid:v},function (data){
			// obj=JSON.parse(data);
			 
			 $("#bookmarkli").html(data);
				/*if(obj[0]==1){
						alert("Bookmarked successfullly.");
				}else if(obj[0]==2){
						alert("You have already bookmarked on "+ obj[1]);
				}else if(obj[0]==0){
						alert("Failed");
				}*/
		})
		
	}
	
	function  removebookmarkArtist(v){
		 
		$.post("resources/ajax/event-action.php",{varremovebookmarkid:v},function (data){
			 
			 //alert(data);
			 $("#bookmarkli").html(data);
				 
		})
		
	}
	
	function youtubeUpoload(){
		$(".dropzonedivv").hide();
		$(".youtubeuploaddiv").show();
	
		
	}
	
	function UpdateYoutubeUrl(){
			var url=$("#youtubeurlTxt").val();
		 
		if(url=='')
		{
			alert("Enter URL.");	
			document.getElementById("youtubeurlTxt").focus();
			return false;
			
		}
		 
		 $.post("resources/ajax/gallery-data.php",{varupdatevideourl:url},function (data){
						// alert(data);
							  if(data==1){
								  $("#video-message").html("Saved successfullly.");
								  $("#youtubeurlTxt").val('');
								  
							  }else{
								  $("#video-message").html("Error occured.Could n't save");
								  $("#youtubeurlTxt").val('');
							  }
						  });
		
	}
	
	
	
	
	
		$(document).ready(function(){
	$('.close').on('click', function() {
				
				
				
				var id =$(this).attr('videoid');
				var r = confirm("Are you sure to delete?");
				 
				if (r == true) {
					
				 $(this).parents('.col-sm-3').remove();
				 $.post("resources/ajax/gallery-data.php",{vardeletevideoid:id},function (data){
						//alert(data);	
							 
						  });
				}
			});	 
			
			
			$('.close2').on('click', function() {
				location.reload();
			})
			
			
		})
		

		
		
			// place an entry in history tbl
	storeUservisitHistory(<?php echo $musicianid;?>,'musician-gallery.php');
	
	//Update user page leave time
   $(window).bind('beforeunload', function(){
	  var parameter='param';
	  var pagename="musician-gallery.php";
	  var whompagevisited=<?php echo $musicianid;?>;
			$.post("resources/ajax/record-user-visit.php",{varwhomidendtime:parameter,varpagename:pagename,varwhompagevisited:whompagevisited},function (data){		
				//alert(data);			 
			
		 })		 
		 
});
  </script>
</body>
</html>