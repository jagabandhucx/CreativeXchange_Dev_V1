<?php 
include("resources/includes/functions.php");
checkLogin();
$title="Change Password ";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
 
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
			 

$query_state="select * from states";
$sql_state = $dbh->prepare($query_state);
             $sql_state->execute();
             	 


$query_cities="select * from cities";
$sql_cities = $dbh->prepare($query_cities);
             $sql_cities->execute();

	
$query_profession="select * from professions where id='$result[professionid]'";
$sql_profession = $dbh->prepare($query_profession);
 $sql_profession->execute();	
$rec_profession_name= $sql_profession->fetch(PDO::FETCH_ASSOC); 
	//echo $rec_profession_name['name'];	 

$name=$result['name'];	





?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		
<style>
#message{
text-align: center;
font-size: 18px;
background-color: #ebf8a4;
color: #000;
border-radius: 2px;
border:1px solid #a2d246;
}
.form-control{
	border-right: #fff;	
}




</style>


</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
			  <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->


			<!-- start: Content -->
			<div id="content" class="col-sm-12">
			
			<form name="passwordform" id="passwordform" method="post">
			 
		 
			<div class="row" >		
				<div class="col-lg-12">
					<div class="box">
					<div style="text-align:center;"> <h1 style="font-weight: 400;color: #4267b2;">   Change Password </h1></div>	
					
					          <div class="row" id="showmessage"  style="display:none;">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										  <div class="row" id="message" >	</div>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
					
	                   
					   
					   
					   	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused" id="current_password" name="current_password"   type="password" placeholder="Current Password" required>
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
					   
					   
					   
					 
					 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused" id="new_password" name="new_password"   type="password" placeholder="New Password" required >
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
							
							
							 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										 <input class="form-control focused" id="confirm_password" name="confirm_password"   type="password" placeholder="Confirm Password" required>
									  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
						 
								 
					 
								
								 
								<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										   <button class="btn btn-mini btn-success chpassword" type="button"  onclick="changePassword()">Change Password</button>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								 
								
								 
								 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										  
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								 
								 	<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										  
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>  
								
								
								 
								
								 
								
								 
						 
					</div>
				</div><!--/col-->
			
			</div><!--/row-->

			</form>
			
			
			
			
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>	
	
		<?php  include("resources/templates/script.php"); ?>
	 <script type="text/javascript">
	 
	                  
 

function changePassword(){
	
	 var current_password=$("#current_password").val();
	  var new_password=$("#new_password").val();
	   var confirm_password=$("#confirm_password").val();
	   
	   
	 
	$.post("resources/ajax/ajax.php",{varcurrent_password:current_password,varnew_password:new_password,varconfirm_password:confirm_password},function (data){
		alert(data);
		  
		if(data==1){
			
			$("#showmessage").show();
			$("#message").html("Password Changeed Successfully.");
					 
		}else if(data==2){
			$("#showmessage").show();
			$("#message").html("Current Password is Wrong.");
			
		}
			
		
	})
	
}
</script>


</body>
</html>
