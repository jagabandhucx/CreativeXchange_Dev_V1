<?php 
include("resources/includes/functions.php");
checkLogin();
$title="Deactivate ";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
 
$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
			 

$query_state="select * from states";
$sql_state = $dbh->prepare($query_state);
             $sql_state->execute();
             	 


$query_cities="select * from cities";
$sql_cities = $dbh->prepare($query_cities);
             $sql_cities->execute();

	
$query_profession="select * from professions where id='$result[professionid]'";
$sql_profession = $dbh->prepare($query_profession);
 $sql_profession->execute();	
$rec_profession_name= $sql_profession->fetch(PDO::FETCH_ASSOC); 
	//echo $rec_profession_name['name'];	 

$name=$result['name'];	





?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		
<style>
#message{
text-align: center;
font-size: 18px;
background-color: #ebf8a4;
color: #000;
border-radius: 2px;
border:1px solid #a2d246;
}
.form-control{
	border-right: #fff;	
}




</style>


</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
			  <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->


			<!-- start: Content -->
			<div id="content" class="col-sm-12">
			<div class="row" >	
			<div class="col-lg-2"></div>
			<div class="col-lg-8">
			<form name="deactivateform" id="deactivateform" method="post" action="account-deactivate-action.php">
			 
						<div class="row"    >		
								<div class="form-group"   >
								 
									<div class="col-lg-12">
									   <span style="font-size:15px; font-weight:600;">Are you sure you want to delete your account?</span><br><br>					   
									   After delete your account, You will lose your  profile and gallery data & can't login to the application further.
									  </div>
								   
								</div>
								</div>
								</br>  
						<div class="row" >		
							<div class="col-lg-12">
								<div class="box" style="border:1px solid #dddfe2; background-color:#f6f7f9;padding-top: 25px;">
				 	
					
					          
										<div class="row">	
										
											  <div class="col-lg-3">
											   &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Reason for leaving
												</div> 
												<div class="col-lg-9">
												<div><input type="radio" name="reasonDeactivate"  value="This is temporary. I'll be back."/> &nbsp; This is temporary. I'll be back. </div>
												
												<div><input type="radio" name="reasonDeactivate" value="I have a privacy concern." /> &nbsp; I have a privacy concern. </div>
												
												<div><input type="radio" name="reasonDeactivate" value="I don't understand how to use CX." /> &nbsp; I don't understand how to use CX. </div>
												
												<div><input type="radio" name="reasonDeactivate" value="I have another CX account." /> &nbsp; I have another CX account. </div>
												
												<div><input type="radio" name="reasonDeactivate"  value="My account was hacked."/> &nbsp; My account was hacked. </div>
												
												<div><input type="radio" name="reasonDeactivate" value="I receive too many emails, invitations and requests from CX. " /> &nbsp; I receive too many emails, invitations and requests from CX. </div>
												
												<div><input type="radio" name="reasonDeactivate" value="I don't feel safe on CX. "/> &nbsp; 	I don't feel safe on CX. </div>
												
												<div><input type="radio" name="reasonDeactivate" value="I don't find CX useful."  /> &nbsp; 	I don't find CX useful. </div>
												<div><input type="radio" name="reasonDeactivate"   value="Other (please explain further):"/> &nbsp; Other (please explain further):		 </div>
												
																						   
											  </div>
										   
										 
										</div>
										</br>  
										<div class="row">	
										
											   <div class="col-lg-3">
											   &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Please explain further	
												</div> 
												<div class="col-lg-9">
												<textarea name="other_reason" id="other_reason" cols="50" rows="3"></textarea>
												</div>
										   
										 
										</div>
										</br>  
										
										<div class="row">	
										
											   <div class="col-lg-3">
											   
												</div> 
												<div class="col-lg-9">
												 <button class="btn btn-mini btn-success" name="btnDeactivate" id="btnDeactivate" type="submit">Delete</button> &nbsp; &nbsp;  <button class="btn btn-mini btn-success" name="btnCancel" id="btnCancel" type="button" onclick="javascript:window.history.back();">Cancel</button>
												</div>
										   
										 
										</div>
										</br>  
	                   
				 
								 
						 
					</div>
				</div><!--/col-->
			
			</div><!--/row-->

			</form>
			</div>
			<div class="col-lg-2"></div>
			 </div>
			
			
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
<?php  include("resources/templates/footer.php"); ?>	
	
<?php  include("resources/templates/script.php"); ?>
		 
 
 
</body>
</html>
