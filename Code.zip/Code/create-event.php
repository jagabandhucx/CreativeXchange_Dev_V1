<?php 
include("resources/includes/functions.php");
checkLogin();
$title="Event ";
$id=$_SESSION["user"];
$user_type=$_SESSION["utype"];
if(isset($_POST['qid']) && $_POST['qid']!=''){
$qid=$_POST['qid'];
}
if(isset($_POST['profession_id']) && $_POST['profession_id']!=''){
$profession_id=$_POST['profession_id'];
}
if(isset($_GET['eid']) && $_GET['eid']!=''){
$edit_eventid=base64_decode($_GET['eid']);
 $sql_eventdtl="select * from  events where id='$edit_eventid'";
$res_events = $dbh->prepare($sql_eventdtl);
             $res_events->execute();
			 $rec_events = $res_events->fetch(PDO::FETCH_ASSOC); 
			 
}

$query="select * from user_register where id='$id'";
$sql = $dbh->prepare($query);
             $sql->execute();
             $result = $sql->fetch(PDO::FETCH_ASSOC); 
			 

$query_state="select * from states";
$sql_state = $dbh->prepare($query_state);
             $sql_state->execute();
             	 


$query_cities="select * from cities";
$sql_cities = $dbh->prepare($query_cities);
             $sql_cities->execute();

	
$query_profession="select * from professions where id='$result[professionid]'";
$sql_profession = $dbh->prepare($query_profession);
 $sql_profession->execute();	
$rec_profession_name= $sql_profession->fetch(PDO::FETCH_ASSOC); 
	//echo $rec_profession_name['name'];	 

$name=$result['name'];			 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php  include("resources/templates/head.php"); ?>		
<style>
#message{
	text-align: center;
font-size: 18px;
background-color: #4267b2;
color: #fff;
border-radius: 2px;
}
 
</style>
</head>

<body>
		<!-- start: Header -->
  <?php  include("resources/templates/header.php"); ?>	
	<!-- end: Header -->
	
		<div class="container">
		<div class="row">

				
			<!-- start: Main Menu -->
			  <?php  include("resources/templates/left-menu.php"); ?>	
			 
			<!-- end: Main Menu -->

			
			<!-- start: Content -->
			<div id="content" class="col-sm-12">
			
			<form name="eventsform" id="eventsform" method="post">
			<input type="hidden" name="uid" id="uid" value="<?php echo $qid;?>"/>
			<input type="hidden" name="profession_id" id="profession_id" value="<?php echo $profession_id;?>"/>
			<?php if(isset($_GET['eid']) && $_GET['eid']!=''){ ?>
			<input type="hidden" name="eventid" id="eventid" value="<?php echo $edit_eventid;?>"/>
			<?php } ?>
			<div class="row">		
				<div class="col-lg-12">
					<div class="box">
					<div style="text-align:center;"> <h1 style="font-weight: 400;color: #4267b2;">
					<?php  if(isset($edit_eventid) && $edit_eventid!=''){ echo "Edit  Event"; }else{ echo "Create  Event";} ?>   </h1></div>	
	                   <div class="row" id="message">	</div> </br> 
	                  <div class="row">	
	                  <div class="form-group">
								 <div class="col-lg-3"></div>
								<div class="col-lg-6">
									<div class="controls">
									<div class="input-group date col-sm-12">
									  <input class="form-control focused input-border-right-white" id="location" name="location"   type="text" placeholder="Event Location" value="<?php if(isset($rec_events['location']) && $rec_events['location']!=''){ echo $rec_events['location']; } ?>">
									<span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
									</div>
									</div>
								  </div>
								  <div class="col-lg-3"></div>
								  </div>
								  
							</div>	</br>  
							
							   <div class="row">  
							<div class="form-group">
							 <div class="col-lg-3"></div>
								  <div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
									
									 
										 Event is Public <input type="radio" name="event_type2" id="public" value="public" style="cursor:pointer;"  <?php if(isset($rec_events['event_cate']) && $rec_events['event_cate']!='' && $rec_events['event_cate']=='public'){ echo "checked"; }?>
										  /> &nbsp;&nbsp;
										Private <input type="radio" name="event_type2" id="private" value="private" style="cursor:pointer;" <?php if(isset($rec_events['event_cate']) && $rec_events['event_cate']!='' && $rec_events['event_cate']=='private'){ echo "checked"; }?> />
 
									</div>	
								  </div>
								   </div>
							 <div class="col-lg-3"></div>
								</div>
								</div>
                               </br>  							
							
							<div class="row">		  
								   <div class="form-group">
									<div class="col-lg-3"></div>
									<div class="col-lg-6">
									<div class="controls">
										<div class="input-group date col-sm-12">									
									  <input class="form-control focused input-border-right-white" id="event_type" name="event_type"   type="text" placeholder="Event Type..Wedding,Birthday,Corporate" value="<?php if(isset($rec_events['event_type']) && $rec_events['event_type']!=''){ echo $rec_events['event_type']; } ?>">
									  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
									</div>
									</div>
									</div>
									 <div class="col-lg-3"></div>
								  </div>
	                        </div>
							</br>  
							
	                        <div class="row">  
							<div class="form-group">
							 <div class="col-lg-3"></div>
								  <div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
									 
										Single Day <input type="radio" name="bookday" id="singledate" value="singledate" style="cursor:pointer;" onclick="getCalendersingle()"  <?php if(isset($rec_events['date_from']) && $rec_events['date_from']!='' && $rec_events['date_from']==$rec_events['date_to']){ echo "checked"; }?> /> &nbsp;&nbsp;
										Multiple Days <input type="radio" name="bookday" id="radiodaterange" value="date_range" style="cursor:pointer;" onclick="getCalendeRange()" <?php if(isset($rec_events['date_from']) && $rec_events['date_from']!='' && $rec_events['date_from']!=$rec_events['date_to']){ echo "checked"; }?> placeholder="Select Date" />
									 
									</div>	
								  </div>
								   </div>
							 <div class="col-lg-3"></div>
								</div>
								</div>
								</br> 

								 
								<?php
								 
								if(isset($rec_events['date_from']) && $rec_events['date_from']!='' && $rec_events['date_from']!=$rec_events['date_to']){
									
								}else{
								
								?>
							<div class="row">		
								<div class="form-group" id="singledaydiv" >
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
								  <div class="controls">
									<div class="input-group date col-sm-12">
										
										<input type="text" class="form-control date-picker input-border-right-white" id="singledate" name="singledate" data-date-format="mm/dd/yyyy"   placeholder="Date"    value="<?php if(isset($rec_events['date_from']) && $rec_events['date_from']!=''){ echo date("m/d/Y",strtotime($rec_events['date_from'])); } ?>"/>
									<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
									</div>	
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								
								</br>  
								<div class="row" id="booking_time" >
								 <div class="col-lg-3"></div>
								<div class="col-lg-3">
								<div class="form-group" id="book_time_from">
								  <!--<label class="control-label" for="timepicker1">From</label>-->
								  <div class="controls">
									<div class="input-group col-sm-12	 bootstrap-timepicker" style="border-right: 1px solid #E5E5E4;">
										
										<input type="text" class="form-control timepicker input-border-right-white" id="timepicker1" name="timefrom" value="7:30 AM" >
										<span class="input-group-addon"><i class="fa fa-clock-o"></i></span>
									</div>	
								  </div>
								</div>
								</div>
								<div class="col-lg-3" style="text-align:right;">
								<div class="form-group" id="book_time_to">
								  <!--<label class="control-label" for="timepicker1">To</label>-->
								  <div class="controls">
									<div class="input-group col-sm-12 bootstrap-timepicker" style="border-right: 1px solid #E5E5E4;">
										
										<input type="text" class="form-control timepicker input-border-right-white" id="timepicker2" value="11:30 AM" name="timeto" >
										<span class="input-group-addon"><i class="fa fa-clock-o"></i></span>
									</div>	
								  </div>
								</div>
								</div>
								 <div class="col-lg-3"></div>
								<!---<div class="col-lg-6">
								<div class="form-group" id="book_time_from">
								  <label class="control-label" for="timepicker1">From</label>
								  <div class="controls">
									<div class="input-group col-sm-8 bootstrap-timepicker">
										<span class="input-group-addon"><i class="fa fa-clock-o"></i></span>
										<input type="text" class="form-control timepicker" id="timepicker3" value="5:30 PM">
									</div>	
								  </div>
								</div>
								</div>
								<div class="col-lg-6">
								<div class="form-group" id="book_time_to">
								  <label class="control-label" for="timepicker1">To</label>
								  <div class="controls">
									<div class="input-group col-sm-8 bootstrap-timepicker">
										<span class="input-group-addon"><i class="fa fa-clock-o"></i></span>
										<input type="text" class="form-control timepicker" id="timepicker4" value="7:30 PM">
									</div>	
								  </div>
								</div>
								</div>--->
								</div>
								
								
								
								<?php
								}
								
								$varsty="display:none";
								if(isset($rec_events['date_from']) && $rec_events['date_from']!='' && $rec_events['date_from']!=$rec_events['date_to']){
									// date range edit
								    $date_from=date("m/d/Y",strtotime($rec_events['date_from']));
									$date_to=date("m/d/Y",strtotime($rec_events['date_to']));
									$varsty="display:block";
								}
								
								?>
								
								
								<div class="row">
								<div class="form-group" id="daterangediv" style="<?php echo $varsty;?>">
								  <div class="col-lg-3"></div>
								 <div class="col-lg-6"> 
								  <div class="controls">
									<div class="input-group col-sm-12">
										
										<input type="text" class="form-control input-border-right-white" id="daterange" name="multipledate" value="<?php
								if(isset($rec_events['date_from']) && $rec_events['date_from']!='' && $rec_events['date_from']!=$rec_events['date_to']){ echo $date_from ."-". $date_to; } ?>"  >
										<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
									</div>
								  </div>
								  </div>
								   <div class="col-lg-3"></div>
								</div>
								</div>
								</br>   
					<div class="row">	
	                  <div class="form-group">
							  <div class="col-lg-3"></div>
								<div class="col-lg-6">
									<div class="controls">
									<div class="input-group col-sm-12">
									
									  <input class="form-control focused input-border-right-white" id="email" name="email"   type="text" placeholder="Email"  value="<?php if(isset($rec_events['email']) && $rec_events['email']!=''){ echo $rec_events['email']; } ?>">
									  	 <span class="input-group-addon"><i class="fa fa-envelope" ></i></span>
									  </div>
									</div>
								  </div>
								  <div class="col-lg-3"></div> 
								  </div>
								  
							</div>	</br>  
								
								<div class="row">	
	                             <div class="form-group">
								  <div class="col-lg-3"></div>
								<div class="col-lg-6">
									<div class="controls">
									<div class="input-group col-sm-12">
										
									  <input class="form-control focused input-border-right-white" id="phone" name="phone"   type="text" placeholder="Mobile"    value="<?php if(isset($rec_events['phone']) && $rec_events['phone']!=''){ echo $rec_events['phone']; } ?>">
									   <span class="input-group-addon"><i class="fa fa-phone"></i></span>
									</div>
									</div>
									
									
									
									
								  </div>
								   <div class="col-lg-3"></div>
								  </div>
								  
							</div>	
							
							</br>  
							<?php //if(isset($rec_events['status']) && $rec_events['status']=='1'){ ?>
							 <div class="row">	
	                             <div class="form-group">
								  <div class="col-lg-3"></div>
								   <div class="col-lg-6">
									<div class="controls">
									<div class="input-group col-sm-12">
										
									  <input class="form-control focused input-border-right-white" id="price" name="price"   type="text" placeholder="Price"   value="<?php if(isset($rec_events['price']) && $rec_events['price']!=''){ echo $rec_events['price']; } ?>" <?php if($rec_events['payment_status']==1){?> readonly<?php } ?>  >
									   <span class="input-group-addon"><i class="fa fa-usd"></i></span>
									</div>
									</div>
									
									
									
									
								  </div>
								   <div class="col-lg-3"></div>
								  </div>
								  
							</div>	 
							
							
							</br>  
							<?php //} ?>
							
							
							
							
							
							
								
								<div class="row">	
	                        <div class="form-group">
							  <div class="col-lg-3"></div>
								<div class="col-lg-2">
									<div class="controls">
									<div class="input-group col-sm-12">
										
									  <input class="form-control focused input-border-right-white" id="facebook" name="facebookurl"   type="text" placeholder="Facebook URL"   value="<?php if(isset($rec_events['fburl']) && $rec_events['fburl']!=''){ echo $rec_events['fburl']; } ?>">
									   <span class="input-group-addon"><i class="fa fa-facebook"></i></span>
									  </div>
									</div>
								  </div>
								  <div class="col-lg-2">
									<div class="controls">
									<div class="input-group col-sm-12">
									
									  <input class="form-control focused input-border-right-white" id="twitter" name="twitterurl"   type="text" placeholder="Twitter URL"   value="<?php if(isset($rec_events['twitterurl']) && $rec_events['twitterurl']!=''){ echo $rec_events['twitterurl']; } ?>">
									  	 <span class="input-group-addon"><i class="fa fa-twitter"></i></span>
									  </div>
									</div>
								  </div>
								  <div class="col-lg-2">
									<div class="controls">
									<div class="input-group col-sm-12">
										
									  <input class="form-control focused input-border-right-white" id="google" name="googleurl"   type="text" placeholder="Google URL"   value="<?php if(isset($rec_events['googleurl']) && $rec_events['googleurl']!=''){ echo $rec_events['googleurl']; } ?>">
									   <span class="input-group-addon"><i class="fa fa-google-plus-square"></i></span>
									  </div>
									</div>
								  </div>
								  <div class="col-lg-3"></div> 
								  </div>
								 
							</div>	</br>  
								
								<div class="row">	
								<div class="form-group">
						          <div class="col-lg-3"></div>
								<div class="col-lg-6">
									  <div class="controls">
										<textarea id="event_details" rows="3" style="width: 100%; overflow: hidden; overflow-wrap: break-word; resize: horizontal; height: 60px;" name="event_details" placeholder="Message"> <?php if(isset($rec_events['message']) && $rec_events['message']!=''){ echo $rec_events['message']; } ?></textarea>
									  </div>
									</div>
									
									 <div class="col-lg-3"></div>
								</div>
								</div>
								</br>
								
								<div class="form-group">
								  <div class="col-lg-3"></div>
								  <div class="col-lg-6">
								  <div class="controls" style="text-align:center">
								   <?php 
								   if(isset($edit_eventid) && $edit_eventid!=''){?>
									    <button class="btn btn-mini btn-success" type="button" onClick="modifyEvents()" style="width: 100%;">Update Event</button>
								 <?php  }else{?>
									   <button class="btn btn-mini btn-success createevent" type="button" style="width: 100%;">Create Event</button>
								<?php }
								   ?>
								   </div>
								   </div>
								   <div class="col-lg-3"></div>
								</div>
							 <!--onClick="createEvents2()" -->
						 
					</div>
				</div><!--/col-->
			
			</div><!--/row-->

			</form>
			
			
			
			
 
		 

    
					
			</div>
			<!-- end: Content -->
			
			 

 		
				</div><!--/row-->
		
		 
		
	</div><!--/container-->
	
		
		
	
	<div class="clearfix"></div>
	
 	<?php  include("resources/templates/footer.php"); ?>	
 
	
		<?php  include("resources/templates/script.php"); ?>
	 <script type="text/javascript">
	 
	                   // $(document).ready(function(){
    // $(".form-control").click(function(){
         // alert("jhii");
    // });
// });
	 
	 
							function getCalendersingle(){
							  $("#singledaydiv").show();
							  $("#booking_time").show();
							  $("#daterangediv").hide();
							  
							  
							
							}
							
							function getCalendeRange(){
							  $("#singledaydiv").hide();
							  $("#booking_time").hide();
							  $("#daterangediv").show();
							  
							
							}
							</script>
	
	
		<script>
		
 
		
		
$(function(){
  $('.searchTerm').on("focus blur", function(){   
   // $(this).parent().toggleClass("expanded collapsed");
     $(this).siblings('.suggestionBox').toggle();
    });
	
	
	
});



function createEvents2(){
	  
	
	 var profession_id=$("#profession_id").val();
	 
	$.post("resources/ajax/event-action.php",$('form#eventsform').serialize(),function (data){
		
		  
		if(data==1){
			$("#message").html("Event created successfully.");
					 
		    window.location.href='gallery.php';
				  
		}
	})
	
}

function modifyEvents(){
	 var profession_id=$("#profession_id").val();
	 
	$.post("resources/ajax/event-action2.php",$('form#eventsform').serialize(),function (data){
		//alert(data);
		   
		if(data==1){
			$("#message").html("Event modified successfully.");
					 
		   
				   
		}
	})
	
}


$(document).ready(function() {

		$('#add-regular2').click(function(){

		$.gritter.add({
			// (string | mandatory) the heading of the notification
			title: 'This is a notice without an image!',
			// (string | mandatory) the text inside the notification
			text: 'This will fade out after a certain amount of time. Vivamus eget tincidunt velit. Cum sociis natoque penatibus et <a href="#" style="color:#ccc">magnis dis parturient</a> montes, nascetur ridiculus mus.'
		});

		return false;

	});
	
	
	
	
})
	
	 
	
	
</script>
</body>
</html>
